<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'number',
    'title',
    'description',
    'id' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'number',
    'title',
    'description',
    'id' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section
    class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] dark:bg-[#2d302e] sm:p-6"
    <?php if($id): ?> aria-labelledby="<?php echo e($id); ?>" <?php endif; ?>
>
    <div class="mb-6 border-b border-[#eef0ec] pb-5">
        <p class="mb-1 text-[10px] font-semibold uppercase tracking-[.18em] text-[#aa8046]"><?php echo e($number); ?></p>
        <h3 <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?> class="font-serif text-xl text-[#28302b] dark:text-[#eeeae2]"><?php echo e($title); ?></h3>
        <p class="mt-1 text-xs text-[#8a938d]"><?php echo e($description); ?></p>
    </div>
    <?php echo e($slot); ?>

</section>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/form-section.blade.php ENDPATH**/ ?>