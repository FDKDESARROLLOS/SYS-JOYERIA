<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'breadcrumbs',
    'title',
    'description',
    'badge' => null,
    'badgeClass' => 'bg-[#e8ddcf] text-[#8f6d43]',
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'breadcrumbs',
    'title',
    'description',
    'badge' => null,
    'badgeClass' => 'bg-[#e8ddcf] text-[#8f6d43]',
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
    <div>
        <div class="mb-2 flex flex-wrap items-center gap-2">
            <nav aria-label="Breadcrumb">
            <ol class="flex flex-wrap items-center gap-2 text-sm text-aurea-muted">
                <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumbItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(! $loop->last && $breadcrumbItem['url']): ?>
                        <li>
                            <a
                                href="<?php echo e($breadcrumbItem['url']); ?>"
                                class="aurea-focus rounded-sm hover:text-aurea-focus"
                            >
                                <?php echo e($breadcrumbItem['label']); ?>

                            </a>
                        </li>
                    <?php else: ?>
                        <li aria-current="page" class="text-[#515b55] dark:text-[#eeeae2]">
                            <?php echo e($breadcrumbItem['label']); ?>

                        </li>
                    <?php endif; ?>
                    <?php if(! $loop->last): ?>
                        <li aria-hidden="true" class="text-[#b2b9b4]">/</li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            </nav>
            <?php if($badge): ?>
                <span class="rounded-full px-2 py-1 text-[10px] font-medium <?php echo e($badgeClass); ?>"><?php echo e($badge); ?></span>
            <?php endif; ?>
        </div>
        <h2 class="font-serif text-3xl text-aurea-ink"><?php echo e($title); ?></h2>
        <p class="mt-2 max-w-2xl text-sm text-aurea-muted"><?php echo e($description); ?></p>
        <?php if($required): ?>
            <p class="mt-3 text-xs text-[#8a938d]"><span class="required-mark">*</span> Campos obligatorios</p>
        <?php endif; ?>
    </div>

    <?php if(isset($actions)): ?>
        <div class="flex flex-wrap items-center gap-2">
            <?php echo e($actions); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/page-header.blade.php ENDPATH**/ ?>