<?php $__env->startSection('content'); ?>
    <?php
        $paymentSettings = config('aurea-demo.payment_settings', []);
        $stripeModes = ['Pruebas', 'Producción'];
        $paypalModes = ['Sandbox', 'Producción'];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Pagos',
                'url' => null,
            ],
        ],'title' => 'Pagos','description' => 'Configura visualmente los proveedores de pago disponibles para '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Pagos',
                'url' => null,
            ],
        ]),'title' => 'Pagos','description' => 'Configura visualmente los proveedores de pago disponibles para '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <button
                type="button"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]"
            >Guardar configuración</button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <form class="space-y-7">
        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Stripe','description' => 'Configura las credenciales para procesar pagos con tarjeta.','id' => 'stripe-settings-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Stripe','description' => 'Configura las credenciales para procesar pagos con tarjeta.','id' => 'stripe-settings-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <div class="sm:col-span-2 border-b border-[#eef0ec] pb-5">
                    <?php if (isset($component)) { $__componentOriginalab5a54c7a6b843251f5286ea214d67cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.toggle','data' => ['id' => 'stripe-enabled','name' => 'stripe_enabled','label' => 'Activar Stripe','description' => 'Permite mostrar Stripe como método de pago disponible.','checked' => $paymentSettings['stripe']['enabled']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'stripe-enabled','name' => 'stripe_enabled','label' => 'Activar Stripe','description' => 'Permite mostrar Stripe como método de pago disponible.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentSettings['stripe']['enabled'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $attributes = $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $component = $__componentOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
                </div>
                <label>
                    <span class="admin-form-label">Modo</span>
                    <select name="stripe_mode" class="admin-form-input">
                        <?php $__currentLoopData = $stripeModes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stripeMode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($stripeMode); ?>" <?php if($paymentSettings['stripe']['mode'] === $stripeMode): echo 'selected'; endif; ?>><?php echo e($stripeMode); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>
                    <span class="admin-form-label">Clave pública</span>
                    <input
                        type="text"
                        name="stripe_public_key"
                        value="<?php echo e($paymentSettings['stripe']['public_key']); ?>"
                        class="admin-form-input"
                    />
                </label>
                <label>
                    <span class="admin-form-label">Clave secreta</span>
                        <input
                            type="password"
                            name="stripe_secret_key"
                            placeholder="••••••••••••"
                            class="admin-form-input"
                    />
                </label>
                <label>
                    <span class="admin-form-label">Webhook secret</span>
                        <input
                            type="password"
                            name="stripe_webhook_secret"
                            placeholder="••••••••••••"
                            class="admin-form-input"
                    />
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '02','title' => 'PayPal','description' => 'Configura las credenciales de tu cuenta de PayPal.','id' => 'paypal-settings-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '02','title' => 'PayPal','description' => 'Configura las credenciales de tu cuenta de PayPal.','id' => 'paypal-settings-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <div class="sm:col-span-2 border-b border-[#eef0ec] pb-5">
                    <?php if (isset($component)) { $__componentOriginalab5a54c7a6b843251f5286ea214d67cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.toggle','data' => ['id' => 'paypal-enabled','name' => 'paypal_enabled','label' => 'Activar PayPal','description' => 'Permite mostrar PayPal como método de pago disponible.','checked' => $paymentSettings['paypal']['enabled']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'paypal-enabled','name' => 'paypal_enabled','label' => 'Activar PayPal','description' => 'Permite mostrar PayPal como método de pago disponible.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentSettings['paypal']['enabled'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $attributes = $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $component = $__componentOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
                </div>
                <label>
                    <span class="admin-form-label">Modo</span>
                    <select name="paypal_mode" class="admin-form-input">
                        <?php $__currentLoopData = $paypalModes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paypalMode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($paypalMode); ?>" <?php if($paymentSettings['paypal']['mode'] === $paypalMode): echo 'selected'; endif; ?>><?php echo e($paypalMode); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>
                    <span class="admin-form-label">Client ID</span>
                    <input
                        type="text"
                        name="paypal_client_id"
                        value="<?php echo e($paymentSettings['paypal']['client_id']); ?>"
                        class="admin-form-input"
                    />
                </label>
                <label>
                    <span class="admin-form-label">Client Secret</span>
                        <input
                            type="password"
                            name="paypal_client_secret"
                            placeholder="••••••••••••"
                            class="admin-form-input"
                    />
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Pagos', 'sectionTitle' => 'Pagos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/payments.blade.php ENDPATH**/ ?>