
<?php echo $__env->make('layouts.error', [
    'code' => '403',
    'title' => 'Acceso restringido',
    'message' => 'No tienes permisos para acceder a esta sección.',
    'actions' => [
        ['label' => 'Volver al dashboard', 'url' => url('/dashboard')],
    ],
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/errors/403.blade.php ENDPATH**/ ?>