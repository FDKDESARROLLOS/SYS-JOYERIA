<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'description',
    'actionUrl' => null,
    'actionLabel' => null,
    'actionType' => 'link',
    'actionId' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'description',
    'actionUrl' => null,
    'actionLabel' => null,
    'actionType' => 'link',
    'actionId' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex flex-col items-center justify-center px-6 py-12 text-center">
    <span class="flex h-12 w-12 items-center justify-center rounded-2xl border border-aurea-border bg-aurea-paper text-aurea-muted dark:bg-[#343633]">
        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
            <rect x="4" y="4" width="16" height="16" rx="2" />
            <path d="M8 9h8M8 13h5M8 17h3" />
        </svg>
    </span>
    <h4 class="mt-4 text-sm font-semibold text-[#343d37] dark:text-[#eeeae2]"><?php echo e($title); ?></h4>
    <p class="mt-1 max-w-sm text-xs leading-5 text-aurea-muted"><?php echo e($description); ?></p>
    <?php if($actionLabel && ($actionUrl || $actionType === 'button')): ?>
        <?php if($actionType === 'button'): ?>
            <button
                type="button"
                <?php if($actionId): ?> id="<?php echo e($actionId); ?>" <?php endif; ?>
                data-clear-filters
                class="aurea-focus mt-5 inline-flex cursor-pointer items-center rounded-lg border border-aurea-border px-3 py-2 text-xs font-medium text-aurea-focus hover:border-aurea-gold hover:bg-aurea-paper"
            >
                <?php echo e($actionLabel); ?>

            </button>
        <?php else: ?>
        <a href="<?php echo e($actionUrl); ?>" class="aurea-focus mt-5 inline-flex items-center rounded-lg bg-aurea-gold px-3 py-2 text-xs font-medium text-white hover:bg-[#966f3f]">
            <?php echo e($actionLabel); ?>

        </a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/empty-state.blade.php ENDPATH**/ ?>