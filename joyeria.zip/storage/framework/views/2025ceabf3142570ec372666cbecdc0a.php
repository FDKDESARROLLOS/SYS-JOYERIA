<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'loadingLabel' => 'Guardando...',
    'type' => 'submit',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'loadingLabel' => 'Guardando...',
    'type' => 'submit',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<button
    type="<?php echo e($type); ?>"
    <?php echo e($attributes->merge(['class' => 'aurea-focus inline-flex cursor-pointer items-center justify-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f] disabled:cursor-not-allowed disabled:border-[#c9c3b9] disabled:bg-[#bdb7ad] disabled:text-white'])); ?>

    data-loading-button
    data-default-label="<?php echo e($label); ?>"
    data-loading-label="<?php echo e($loadingLabel); ?>"
>
    <span data-button-label><?php echo e($label); ?></span>
    <svg data-button-spinner class="hidden h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="8" class="opacity-30" stroke="currentColor" stroke-width="2" />
        <path d="M20 12a8 8 0 0 0-8-8" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
    </svg>
</button>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/loading-button.blade.php ENDPATH**/ ?>