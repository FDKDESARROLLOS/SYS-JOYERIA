<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            ['label' => 'Catálogo', 'url' => route('products.index')],
            ['label' => 'Productos', 'url' => null],
        ],'title' => 'Productos','description' => 'Gestiona las piezas que forman parte del catálogo de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Catálogo', 'url' => route('products.index')],
            ['label' => 'Productos', 'url' => null],
        ]),'title' => 'Productos','description' => 'Gestiona las piezas que forman parte del catálogo de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a href="<?php echo e(route('products.create')); ?>"
                class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f]">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                    <path d="M12 5v14M5 12h14" />
                </svg>
                Nuevo producto
            </a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.flash-messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.flash-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $attributes = $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $component = $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>

    <section class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6"
        aria-labelledby="product-filters-title">
        <div class="mb-5">
            <h3 id="product-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar productos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Busca por datos comerciales o filtra por clasificación y estado.</p>
        </div>
        <form method="GET" action="<?php echo e(route('products.index')); ?>" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <label class="sm:col-span-2 lg:col-span-4">
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar producto</span>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>"
                    placeholder="Nombre, modelo, código, SKU o slug"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold" />
            </label>

            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Categoría</span>
                <select name="category_id" class="admin-form-input">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if((string) request('category_id') === (string) $category->id): echo 'selected'; endif; ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>

            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Colección</span>
                <select name="collection_id" class="admin-form-input">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($collection->id); ?>" <?php if((string) request('collection_id') === (string) $collection->id): echo 'selected'; endif; ?>>
                            <?php echo e($collection->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>

            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Estado</span>
                <select name="status" class="admin-form-input">
                    <option value="">Todos</option>
                    <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Activo</option>
                    <option value="draft" <?php if(request('status') === 'draft'): echo 'selected'; endif; ?>>Borrador</option>
                    <option value="inactive" <?php if(request('status') === 'inactive'): echo 'selected'; endif; ?>>Inactivo</option>
                </select>
            </label>

            <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-end">
                <button type="submit"
                    class="aurea-focus inline-flex w-full items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f] sm:w-auto">Aplicar filtros</button>
                <a href="<?php echo e(route('products.index')); ?>"
                    class="aurea-focus inline-flex w-full items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] transition hover:border-aurea-gold hover:text-aurea-focus sm:w-auto">Limpiar</a>
            </div>
        </form>
    </section>

    <section class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="products-list-title">
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="products-list-title" class="font-serif text-xl text-[#28302b]">Listado de productos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Mostrando <?php echo e($products->total()); ?> productos.</p>
        </div>

        <?php if($products->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay productos todavía','description' => 'Agrega un producto para comenzar a construir tu catálogo.','actionUrl' => route('products.create'),'actionLabel' => 'Agregar producto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay productos todavía','description' => 'Agrega un producto para comenzar a construir tu catálogo.','action-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.create')),'action-label' => 'Agregar producto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="hidden overflow-x-auto sm:block">
                <table class="admin-table w-full min-w-190 text-left text-sm">
                    <caption class="sr-only">Listado de productos</caption>
                    <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                        <tr>
                            <th scope="col" class="px-5 py-3 font-medium sm:px-6">Producto</th>
                            <th scope="col" class="px-3 py-3 font-medium">Código</th>
                            <th scope="col" class="px-3 py-3 font-medium">Categoría</th>
                            <th scope="col" class="px-3 py-3 font-medium">Colección</th>
                            <th scope="col" class="px-3 py-3 font-medium">Precio</th>
                            <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                            <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#f0f1ed]">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $productImage = $product->images->first();
                            ?>
                            <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                                <td class="px-5 py-4 sm:px-6">
                                    <div class="flex items-center gap-3">
                                        <div class="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#e7e2da] bg-[#f7f3ec] dark:border-[#4b4a45] dark:bg-[#292b29]">
                                            <?php if($productImage?->hasPublicFile()): ?>
                                                <img src="<?php echo e($productImage->publicUrl()); ?>" alt="<?php echo e($productImage->alt ?: $product->name); ?>"
                                                    class="block h-full w-full object-cover" />
                                            <?php else: ?>
                                                <span class="text-xs text-[#a6ada7] dark:text-[#777d77]" aria-hidden="true">—</span>
                                                <span class="sr-only">Sin imagen</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="min-w-0">
                                            <p class="font-medium text-[#343d37]"><?php echo e($product->name); ?></p>
                                            <p class="mt-1 text-[11px] text-[#929b94]"><?php echo e($product->model ?: 'Sin modelo'); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-3 py-4 text-xs text-[#929b94]"><?php echo e($product->code); ?></td>
                                <td class="px-3 py-4"><?php echo e($product->category?->name ?? 'Sin categoría'); ?></td>
                                <td class="px-3 py-4"><?php echo e($product->collection?->name ?? 'Sin colección'); ?></td>
                                <td class="px-3 py-4 font-medium text-[#343d37]">$<?php echo e(number_format((float) $product->price, 2)); ?></td>
                                <td class="px-3 py-4">
                                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => match ($product->status) {
                                            'active' => 'Activo',
                                            'inactive' => 'Inactivo',
                                            default => 'Borrador',
                                        },'statusClass' => match ($product->status) {
                                            'active' => 'text-[#5b8668]',
                                            'inactive' => 'text-[#a27a3f]',
                                            default => 'text-[#806441]',
                                        }]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match ($product->status) {
                                            'active' => 'Activo',
                                            'inactive' => 'Inactivo',
                                            default => 'Borrador',
                                        }),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match ($product->status) {
                                            'active' => 'text-[#5b8668]',
                                            'inactive' => 'text-[#a27a3f]',
                                            default => 'text-[#806441]',
                                        })]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                                </td>
                                <td class="px-5 py-4 text-right sm:px-6">
                                    <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $product->name,'editUrl' => route('products.edit', $product),'secondaryUrl' => route('products.variants.index', $product),'secondaryLabel' => 'Variantes','deleteLabel' => 'producto','deleteUrl' => route('products.destroy', $product)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.edit', $product)),'secondary-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.index', $product)),'secondary-label' => 'Variantes','delete-label' => 'producto','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.destroy', $product))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="divide-y divide-[#f0f1ed] sm:hidden">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $productImage = $product->images->first();
                            ?>
                            <article class="px-5 py-4">
                                <div class="flex items-start justify-between gap-3">
                                    <div class="flex min-w-0 items-center gap-3">
                                        <div class="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#e7e2da] bg-[#f7f3ec] dark:border-[#4b4a45] dark:bg-[#292b29]">
                                            <?php if($productImage?->hasPublicFile()): ?>
                                                <img src="<?php echo e($productImage->publicUrl()); ?>" alt="<?php echo e($productImage->alt ?: $product->name); ?>"
                                                    class="block h-full w-full object-cover" />
                                            <?php else: ?>
                                                <span class="text-xs text-[#a6ada7] dark:text-[#777d77]" aria-hidden="true">—</span>
                                                <span class="sr-only">Sin imagen</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="min-w-0">
                                            <p class="text-sm font-medium text-[#343d37]"><?php echo e($product->name); ?></p>
                                            <p class="mt-1 text-xs text-[#929b94]"><?php echo e($product->code); ?> · <?php echo e($product->category?->name ?? 'Sin categoría'); ?></p>
                                        </div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $product->status === 'active' ? 'Activo' : ($product->status === 'inactive' ? 'Inactivo' : 'Borrador'),'statusClass' => $product->status === 'active' ? 'text-[#5b8668]' : ($product->status === 'inactive' ? 'text-[#a27a3f]' : 'text-[#806441]' )]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->status === 'active' ? 'Activo' : ($product->status === 'inactive' ? 'Inactivo' : 'Borrador')),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->status === 'active' ? 'text-[#5b8668]' : ($product->status === 'inactive' ? 'text-[#a27a3f]' : 'text-[#806441]' ))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                        </div>
                        <div class="mt-3 flex items-end justify-between gap-3">
                            <div>
                                <p class="text-sm font-medium text-[#343d37]">$<?php echo e(number_format((float) $product->price, 2)); ?></p>
                                <p class="mt-1 text-[11px] text-[#929b94]"><?php echo e($product->collection?->name ?? 'Sin colección'); ?></p>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $product->name,'editUrl' => route('products.edit', $product),'secondaryUrl' => route('products.variants.index', $product),'secondaryLabel' => 'Variantes','deleteLabel' => 'producto','deleteUrl' => route('products.destroy', $product)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.edit', $product)),'secondary-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.index', $product)),'secondary-label' => 'Variantes','delete-label' => 'producto','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.destroy', $product))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="border-t border-[#eef0ec] px-5 py-4 sm:px-6">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Productos', 'sectionTitle' => 'Productos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/products/index.blade.php ENDPATH**/ ?>