<div
    id="delete-confirmation"
    class="fixed inset-0 z-50 hidden items-center justify-center bg-[#222222]/25 px-5 backdrop-blur-sm dark:bg-[#111412]/55"
    role="presentation"
>
    <div
        class="w-full max-w-md rounded-2xl border border-aurea-border bg-white p-6 shadow-[0_18px_50px_rgba(35,42,37,0.16)] dark:bg-[#2d302e]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-confirmation-title"
        aria-describedby="delete-confirmation-description"
    >
        <div class="flex items-start gap-4">
            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f9e9e6] text-aurea-danger">
                <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => 'trash','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
            </div>
            <div>
                <h2 id="delete-confirmation-title" class="font-serif text-xl text-aurea-ink">¿Eliminar este registro?</h2>
                <p id="delete-confirmation-description" class="mt-2 text-sm leading-6 text-aurea-muted">Esta acción eliminará el registro. ¿Deseas continuar?</p>
            </div>
        </div>
        <div class="mt-6 flex justify-end gap-2">
            <button
                type="button"
                id="delete-confirmation-cancel"
                class="aurea-focus rounded-lg border border-aurea-border px-4 py-2.5 text-sm font-medium text-aurea-muted hover:bg-aurea-paper"
            >Cancelar</button>
            <button
                type="button"
                id="delete-confirmation-confirm"
                class="aurea-focus rounded-lg bg-aurea-danger px-4 py-2.5 text-sm font-medium text-white hover:bg-[#8f554a]"
            >Eliminar</button>
        </div>
    </div>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/delete-confirmation.blade.php ENDPATH**/ ?>