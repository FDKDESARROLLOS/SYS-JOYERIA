<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Catálogo',
                'url' => route('products.index'),
            ],
            [
                'label' => 'Tallas',
                'url' => null,
            ],
        ],'title' => 'Tallas','description' => 'Organiza las medidas disponibles para que cada pieza de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).' encuentre su ajuste ideal.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Catálogo',
                'url' => route('products.index'),
            ],
            [
                'label' => 'Tallas',
                'url' => null,
            ],
        ]),'title' => 'Tallas','description' => 'Organiza las medidas disponibles para que cada pieza de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).' encuentre su ajuste ideal.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a
                href="<?php echo e(route('sizes.create')); ?>"
                class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f]"
            >
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"
                    aria-hidden="true">
                    <path d="M12 5v14M5 12h14" />
                </svg>
                Nueva talla
            </a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.flash-messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.flash-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $attributes = $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $component = $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>

    <section
        class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6"
        aria-labelledby="size-filters-title"
    >
        <div class="mb-5">
            <h3 id="size-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar tallas</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Encuentra rápidamente una talla por su medida o categoría.</p>
        </div>
        <form method="GET" action="<?php echo e(route('sizes.index')); ?>" class="grid gap-4 sm:grid-cols-2">
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar talla</span>
                <input
                    type="search"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Ej. 7 o 18 cm"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold"
                />
            </label>
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Estado</span>
                <select
                    name="status"
                    class="aurea-focus w-full appearance-none rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none hover:border-aurea-gold-soft dark:border-[#4b4a45] dark:bg-[#292b29] dark:text-[#f1eee8]"
                >
                    <option value="">Todos</option>
                    <option value="1" <?php if(request('status') === '1'): echo 'selected'; endif; ?>>Activo</option>
                    <option value="0" <?php if(request('status') === '0'): echo 'selected'; endif; ?>>Inactivo</option>
                </select>
            </label>
            <div class="flex flex-col gap-3 sm:col-span-2 sm:flex-row sm:justify-end">
                <button
                    type="submit"
                    class="aurea-focus inline-flex w-full items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f] sm:w-auto"
                >
                    Aplicar filtros
                </button>
                <a
                    href="<?php echo e(route('sizes.index')); ?>"
                    class="aurea-focus inline-flex w-full items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] transition hover:border-aurea-gold hover:text-aurea-focus dark:border-[#4b4a45] dark:text-[#d0d4cf] dark:hover:border-[#b99562] dark:hover:text-[#e6cda9] sm:w-auto"
                >
                    Limpiar
                </a>
            </div>
        </form>
    </section>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="sizes-list-title"
    >
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="sizes-list-title" class="font-serif text-xl text-[#28302b]">Listado de tallas</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Mostrando <?php echo e($sizes->total()); ?> tallas.</p>
        </div>

        <?php if($sizes->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay tallas todavía','description' => 'Agrega una talla para definir las opciones disponibles por categoría.','actionUrl' => route('sizes.create'),'actionLabel' => 'Agregar talla']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay tallas todavía','description' => 'Agrega una talla para definir las opciones disponibles por categoría.','action-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('sizes.create')),'action-label' => 'Agregar talla']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
        <div class="hidden overflow-x-auto sm:block">
            <table class="admin-table w-full min-w-190 text-left text-sm">
                <caption class="sr-only">Listado de tallas de <?php echo e(config('aurea-demo.store_settings.store_name', 'Tienda')); ?></caption>
                <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                    <tr>
                        <th scope="col" class="px-5 py-3 font-medium sm:px-6">Nombre</th>
                        <th scope="col" class="px-3 py-3 font-medium">Categorías</th>
                        <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                        <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#f0f1ed]">
                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                            <td class="px-5 py-4 sm:px-6">
                                <p class="font-medium text-[#343d37]"><?php echo e($size->name); ?></p>
                            </td>
                            <td class="px-3 py-4">
                                <?php if($size->categories->isEmpty()): ?>
                                    <span class="text-xs text-[#929b94]">Sin categorías</span>
                                <?php else: ?>
                                    <div class="flex flex-wrap gap-1.5">
                                        <?php $__currentLoopData = $size->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="rounded-full bg-[#f6f3ed] px-2 py-1 text-xs text-[#6f634f]">
                                                <?php echo e($category->name); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="px-3 py-4">
                                <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $size->status ? 'Activo' : 'Inactivo','statusClass' => $size->status ? 'text-[#5b8668]' : 'text-[#a27a3f]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->status ? 'Activo' : 'Inactivo'),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->status ? 'text-[#5b8668]' : 'text-[#a27a3f]')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                            </td>
                            <td class="px-5 py-4 text-right sm:px-6">
                                <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $size->name,'editUrl' => route('sizes.edit', $size),'deleteLabel' => 'talla','deleteUrl' => route('sizes.destroy', $size)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('sizes.edit', $size)),'delete-label' => 'talla','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('sizes.destroy', $size))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="divide-y divide-[#f0f1ed] sm:hidden">
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="px-5 py-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-[#343d37]"><?php echo e($size->name); ?></p>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $size->status ? 'Activo' : 'Inactivo','statusClass' => $size->status ? 'text-[#5b8668]' : 'text-[#a27a3f]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->status ? 'Activo' : 'Inactivo'),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->status ? 'text-[#5b8668]' : 'text-[#a27a3f]')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                    </div>
                    <div class="mt-3 flex justify-end">
                        <div class="mr-auto text-xs text-[#929b94]">
                            <span>Categorías:</span>
                            <span class="ml-1 text-[#5b655e]">
                                <?php echo e($size->categories->pluck('name')->join(', ') ?: 'Sin categorías'); ?>

                            </span>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $size->name,'editUrl' => route('sizes.edit', $size),'deleteLabel' => 'talla','deleteUrl' => route('sizes.destroy', $size)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('sizes.edit', $size)),'delete-label' => 'talla','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('sizes.destroy', $size))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="border-t border-[#eef0ec] px-5 py-4 sm:px-6">
            <?php echo e($sizes->links()); ?>

        </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Tallas', 'sectionTitle' => 'Tallas'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/sizes/index.blade.php ENDPATH**/ ?>