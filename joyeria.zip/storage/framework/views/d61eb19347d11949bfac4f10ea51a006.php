<?php $__env->startSection('content'); ?>
    <div>
        <p class="text-[10px] font-semibold uppercase tracking-[.22em] text-aurea-focus">
            Nueva contraseña
        </p>

        <h2 id="auth-title" class="mt-3 font-brand text-4xl text-[#222222]">
            Crear nueva contraseña
        </h2>

        <p class="mt-3 text-sm leading-6 text-aurea-muted">
            Define una nueva contraseña para volver a acceder al panel administrativo.
        </p>
    </div>

    <form method="POST" action="<?php echo e(route('password.update')); ?>" class="mt-8 space-y-5" aria-label="Crear nueva contraseña">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <input type="hidden" name="email" value="<?php echo e(old('email', $email)); ?>">

        <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['id' => 'new-password','name' => 'password','label' => 'Nueva contraseña','autocomplete' => 'new-password','placeholder' => 'Ingresa una nueva contraseña']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'new-password','name' => 'password','label' => 'Nueva contraseña','autocomplete' => 'new-password','placeholder' => 'Ingresa una nueva contraseña']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['id' => 'confirm-password','name' => 'password_confirmation','label' => 'Confirmar contraseña','autocomplete' => 'new-password','placeholder' => 'Repite la nueva contraseña']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'confirm-password','name' => 'password_confirmation','label' => 'Confirmar contraseña','autocomplete' => 'new-password','placeholder' => 'Repite la nueva contraseña']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <button type="submit"
            class="aurea-focus inline-flex w-full cursor-pointer items-center justify-center rounded-lg bg-aurea-gold px-4 py-3 text-sm font-medium text-white shadow-sm hover:bg-[#966f3f]">
            Actualizar contraseña
        </button>

        <a href="<?php echo e(route('login')); ?>"
            class="aurea-focus flex w-full items-center justify-center rounded-lg border border-aurea-border px-4 py-3 text-sm font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus">
            Volver a iniciar sesión
        </a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Crear nueva contraseña'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/auth/reset-password.blade.php ENDPATH**/ ?>