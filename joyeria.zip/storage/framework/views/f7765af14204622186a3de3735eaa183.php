<?php $__env->startSection('content'); ?>
    <?php
        $catalogProducts = collect(config('aurea-demo.catalog_products', []));
        $productImageForSku = fn ($sku) => $catalogProducts->first(
            fn ($product) => $sku === $product['base_sku'] || str_starts_with($sku, $product['base_sku'] . '-')
        )['image'] ?? null;
        $inventoryRows = collect(config('aurea-demo.inventory_stock'))->map(function ($inventoryItem) use ($productImageForSku) {
            if ($inventoryItem['current_stock'] === 0) {
                $stockStatus = 'Sin stock';
                $stockStatusClass = 'text-aurea-danger';
            } elseif ($inventoryItem['current_stock'] <= $inventoryItem['minimum_stock']) {
                $stockStatus = 'Stock bajo';
                $stockStatusClass = 'text-[#947142]';
            } else {
                $stockStatus = 'Disponible';
                $stockStatusClass = 'text-[#5b8668]';
            }

            return array_merge($inventoryItem, [
                'image' => $productImageForSku($inventoryItem['sku']),
                'stock_status' => $stockStatus,
                'stock_status_class' => $stockStatusClass,
            ]);
        });
        $inventoryCategories = $inventoryRows->pluck('category')->unique()->values()->all();
        $inventoryStatuses = ['Disponible', 'Stock bajo', 'Sin stock'];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Inventario',
                'url' => null,
            ],
            [
                'label' => 'Existencias',
                'url' => null,
            ],
        ],'title' => 'Existencias','description' => 'Consulta el stock actual de tus productos y variantes sin modificar sus cantidades.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Inventario',
                'url' => null,
            ],
            [
                'label' => 'Existencias',
                'url' => null,
            ],
        ]),'title' => 'Existencias','description' => 'Consulta el stock actual de tus productos y variantes sin modificar sus cantidades.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <section
        class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6"
        aria-labelledby="stock-filters-title"
    >
        <div class="mb-5">
            <h3 id="stock-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar existencias</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Encuentra rápidamente un producto o revisa los niveles de stock.</p>
        </div>
        <div class="grid gap-4 sm:grid-cols-3">
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar por nombre o SKU</span>
                <input
                    type="search"
                    placeholder="Ej. Anillo Aura o AU-1048-T7"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold"
                />
            </label>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['label' => 'Categoría','options' => $inventoryCategories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Categoría','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryCategories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['label' => 'Estado de stock','options' => $inventoryStatuses]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Estado de stock','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryStatuses)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
        </div>
    </section>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="stock-list-title"
    >
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="stock-list-title" class="font-serif text-xl text-[#28302b]">Stock actual</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Mostrando <?php echo e($inventoryRows->count()); ?> productos y variantes ficticios.</p>
        </div>

        <?php if($inventoryRows->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay existencias todavía','description' => 'El stock actual de productos y variantes aparecerá aquí.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay existencias todavía','description' => 'El stock actual de productos y variantes aparecerá aquí.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
        <div class="hidden overflow-x-auto sm:block">
            <table class="admin-table w-full min-w-220 text-left text-sm">
                <caption class="sr-only">Existencias actuales de productos y variantes</caption>
                <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                    <tr>
                        <th scope="col" class="px-5 py-3 font-medium sm:px-6">Producto</th>
                        <th scope="col" class="px-3 py-3 font-medium">Variante</th>
                        <th scope="col" class="px-3 py-3 font-medium">SKU</th>
                        <th scope="col" class="px-3 py-3 font-medium">Categoría</th>
                        <th scope="col" class="px-3 py-3 font-medium">Stock actual</th>
                        <th scope="col" class="px-3 py-3 font-medium">Stock mínimo</th>
                        <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                        <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#f0f1ed]">
                    <?php $__currentLoopData = $inventoryRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                            <td class="px-5 py-4 sm:px-6">
                                <div class="flex items-center gap-3">
                                    <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $inventoryRow['image'],'alt' => $inventoryRow['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['image']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                    <p class="font-medium text-[#343d37]"><?php echo e($inventoryRow['product']); ?></p>
                                </div>
                            </td>
                            <td class="px-3 py-4"><?php echo e($inventoryRow['variant']); ?></td>
                            <td class="px-3 py-4 text-xs text-[#929b94]"><?php echo e($inventoryRow['sku']); ?></td>
                            <td class="px-3 py-4"><?php echo e($inventoryRow['category']); ?></td>
                            <td class="px-3 py-4 font-medium <?php echo e($inventoryRow['current_stock'] === 0 ? 'text-aurea-danger' : 'text-[#343d37]'); ?>">
                                <?php echo e($inventoryRow['current_stock']); ?>

                            </td>
                            <td class="px-3 py-4 text-[#929b94]"><?php echo e($inventoryRow['minimum_stock']); ?></td>
                            <td class="px-3 py-4">
                                <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $inventoryRow['stock_status'],'statusClass' => $inventoryRow['stock_status_class']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['stock_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['stock_status_class'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                            </td>
                            <td class="px-5 py-4 text-right sm:px-6">
                                <a
                                    href="<?php echo e(route('inventory.movements', ['sku' => $inventoryRow['sku']])); ?>"
                                    class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus"
                                    aria-label="Ver movimientos de <?php echo e($inventoryRow['product']); ?> <?php echo e($inventoryRow['variant']); ?>"
                                >
                                    Ver movimientos
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="divide-y divide-[#f0f1ed] sm:hidden">
            <?php $__currentLoopData = $inventoryRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="px-5 py-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex min-w-0 items-center gap-3">
                            <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $inventoryRow['image'],'alt' => $inventoryRow['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['image']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                            <div class="min-w-0">
                                <p class="text-sm font-medium text-[#343d37]"><?php echo e($inventoryRow['product']); ?></p>
                            <p class="mt-1 text-xs text-[#929b94]"><?php echo e($inventoryRow['variant']); ?></p>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $inventoryRow['stock_status'],'statusClass' => $inventoryRow['stock_status_class']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['stock_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventoryRow['stock_status_class'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                    </div>
                    <dl class="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                        <div>
                            <dt class="text-[#929b94]">SKU</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($inventoryRow['sku']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Categoría</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($inventoryRow['category']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Stock</dt>
                            <dd class="mt-0.5 font-medium text-[#343d37]">
                                <?php echo e($inventoryRow['current_stock']); ?> / <?php echo e($inventoryRow['minimum_stock']); ?> mínimo
                            </dd>
                        </div>
                    </dl>
                    <div class="mt-3 flex justify-end">
                        <a
                            href="<?php echo e(route('inventory.movements', ['sku' => $inventoryRow['sku']])); ?>"
                            class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus"
                            aria-label="Ver movimientos de <?php echo e($inventoryRow['product']); ?> <?php echo e($inventoryRow['variant']); ?>"
                        >
                            Ver movimientos
                        </a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Existencias', 'sectionTitle' => 'Existencias'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/inventory/stock.blade.php ENDPATH**/ ?>