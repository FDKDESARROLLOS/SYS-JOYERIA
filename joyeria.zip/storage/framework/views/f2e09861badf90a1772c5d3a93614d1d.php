<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'editUrl' => null,
    'secondaryUrl' => null,
    'secondaryLabel' => null,
    'deleteLabel' => null,
    'deleteUrl' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'editUrl' => null,
    'secondaryUrl' => null,
    'secondaryLabel' => null,
    'deleteLabel' => null,
    'deleteUrl' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="inline-flex items-center gap-1">
    <?php if($editUrl): ?>
        <a href="<?php echo e($editUrl); ?>"
            class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-gold hover:bg-aurea-paper"
            aria-label="Editar <?php echo e($label); ?>">
            Editar
        </a>
    <?php endif; ?>

    <?php if($secondaryUrl && $secondaryLabel): ?>
        <a href="<?php echo e($secondaryUrl); ?>"
            class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus"
            aria-label="<?php echo e($secondaryLabel); ?> de <?php echo e($label); ?>">
            <?php echo e($secondaryLabel); ?>

        </a>
    <?php endif; ?>
    <?php if($deleteLabel && $deleteUrl): ?>
        <button type="button"
            class="delete-record-trigger aurea-focus rounded-md p-2 text-[#6f675d] hover:bg-[#f9e9e6] hover:text-aurea-danger"
            data-delete-trigger data-delete-label="<?php echo e($deleteLabel); ?>" data-delete-name="<?php echo e($label); ?>"
            data-delete-url="<?php echo e($deleteUrl); ?>" aria-label="Eliminar <?php echo e($label); ?>"
            title="Eliminar <?php echo e($label); ?>">
            <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => 'trash','class' => 'h-[18px] w-[18px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'h-[18px] w-[18px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
        </button>
    <?php endif; ?>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/row-actions.blade.php ENDPATH**/ ?>