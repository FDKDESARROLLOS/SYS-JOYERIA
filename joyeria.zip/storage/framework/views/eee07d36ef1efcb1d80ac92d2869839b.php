<?php $__env->startSection('content'); ?>
    <?php
        $shippingSettings = config('aurea-demo.shipping_settings', []);
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
        [
            'label' => 'Configuración',
            'url' => null,
        ],
        [
            'label' => 'Envíos',
            'url' => null,
        ],
    ],'title' => 'Envíos','description' => 'Configura el método general y las condiciones de envío de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        [
            'label' => 'Configuración',
            'url' => null,
        ],
        [
            'label' => 'Envíos',
            'url' => null,
        ],
    ]),'title' => 'Envíos','description' => 'Configura el método general y las condiciones de envío de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <button type="button"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]">Guardar
                configuración</button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <form class="space-y-7">
        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Configuración general','description' => 'Define el método de envío que estará disponible para los pedidos de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'shipping-general-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Configuración general','description' => 'Define el método de envío que estará disponible para los pedidos de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'shipping-general-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <div class="sm:col-span-2 border-b border-[#eef0ec] pb-5">
                    <?php if (isset($component)) { $__componentOriginalab5a54c7a6b843251f5286ea214d67cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.toggle','data' => ['id' => 'shipping-enabled','name' => 'shipping_enabled','label' => 'Activar envíos','description' => 'Permite ofrecer envíos como parte del proceso de compra.','checked' => $shippingSettings['enabled']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'shipping-enabled','name' => 'shipping_enabled','label' => 'Activar envíos','description' => 'Permite ofrecer envíos como parte del proceso de compra.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($shippingSettings['enabled'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $attributes = $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $component = $__componentOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
                </div>
                <label>
                    <span class="admin-form-label admin-form-label-required">Nombre del método</span>
                    <input type="text" name="method_name" value="<?php echo e($shippingSettings['method_name']); ?>"
                        placeholder="Ej. Envío estándar" class="admin-form-input" required />
                </label>
                <label>
                    <span class="admin-form-label admin-form-label-required">Tiempo estimado</span>
                    <input type="text" name="estimated_time" value="<?php echo e($shippingSettings['estimated_time']); ?>"
                        placeholder="Ej. 2 a 5 días hábiles" class="admin-form-input" required />
                </label>
                <label>
                    <span class="admin-form-label admin-form-label-required">Costo de envío</span>
                    <div class="admin-form-input-prefix">
                        <span>$</span>
                        <input type="number" name="shipping_cost"
                            value="<?php echo e(number_format((float) ($shippingSettings['shipping_cost'] ?? 0), 2, '.', '')); ?>"
                            min="0" step="0.01" inputmode="decimal" aria-label="Costo de envío"
                            aria-describedby="shipping-cost-help" required />
                        <span>MXN</span>
                    </div>
                    <span id="shipping-cost-help" class="admin-form-help">Este costo se aplicará cuando el pedido no tenga
                        envío gratis.</span>
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '02','title' => 'Envío gratis','description' => 'Define cuándo los pedidos pueden obtener envío gratis.','id' => 'free-shipping-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '02','title' => 'Envío gratis','description' => 'Define cuándo los pedidos pueden obtener envío gratis.','id' => 'free-shipping-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <div class="sm:col-span-2 border-b border-[#eef0ec] pb-5" id="free-shipping-toggle">
                    <?php if (isset($component)) { $__componentOriginalab5a54c7a6b843251f5286ea214d67cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.toggle','data' => ['id' => 'free-shipping-enabled','name' => 'free_shipping_enabled','label' => 'Activar envío gratis','description' => 'Permite ofrecer envío gratis para todos los pedidos o solo a partir de un monto mínimo.','checked' => $shippingSettings['free_shipping_enabled']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'free-shipping-enabled','name' => 'free_shipping_enabled','label' => 'Activar envío gratis','description' => 'Permite ofrecer envío gratis para todos los pedidos o solo a partir de un monto mínimo.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($shippingSettings['free_shipping_enabled'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $attributes = $__attributesOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__attributesOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb)): ?>
<?php $component = $__componentOriginalab5a54c7a6b843251f5286ea214d67cb; ?>
<?php unset($__componentOriginalab5a54c7a6b843251f5286ea214d67cb); ?>
<?php endif; ?>
                </div>
                <?php
                    $freeShippingType = $shippingSettings['free_shipping_type'] ?? 'minimum';
                ?>
                <div id="free-shipping-type-field"
                    class="<?php echo e($shippingSettings['free_shipping_enabled'] ? '' : 'hidden'); ?> sm:col-span-2 sm:max-w-md"
                    <?php if(!$shippingSettings['free_shipping_enabled']): ?> aria-hidden="true" <?php endif; ?>>
                    <label for="free-shipping-type">
                        <span class="admin-form-label">Modalidad de envío gratis</span>
                        <select id="free-shipping-type" name="free_shipping_type" class="admin-form-input">
                            <option value="all" <?php if($freeShippingType === 'all'): echo 'selected'; endif; ?>>Para todos los pedidos</option>
                            <option value="minimum" <?php if($freeShippingType === 'minimum'): echo 'selected'; endif; ?>>A partir de un monto mínimo</option>
                        </select>
                        <span id="free-shipping-all-help"
                            class="admin-form-help <?php echo e($shippingSettings['free_shipping_enabled'] && $freeShippingType === 'all' ? '' : 'hidden'); ?>"
                            <?php if(!$shippingSettings['free_shipping_enabled'] || $freeShippingType !== 'all'): ?> aria-hidden="true" <?php endif; ?>>Todos los pedidos tendrán envío
                            gratis.</span>
                    </label>
                </div>
                <div id="free-shipping-minimum-field"
                    class="<?php echo e($shippingSettings['free_shipping_enabled'] && $freeShippingType === 'minimum' ? '' : 'hidden'); ?> sm:max-w-md"
                    <?php if(!$shippingSettings['free_shipping_enabled'] || $freeShippingType !== 'minimum'): ?> aria-hidden="true" <?php endif; ?>>
                    <label>
                        <span class="admin-form-label">Monto mínimo</span>
                        <div class="admin-form-input-prefix">
                            <span>$</span>
                            <input type="number" name="free_shipping_minimum"
                                value="<?php echo e(filled($shippingSettings['free_shipping_minimum']) ? number_format((float) $shippingSettings['free_shipping_minimum'], 2, '.', '') : ''); ?>"
                                min="0" step="0.01" inputmode="decimal"
                                aria-label="Monto mínimo para envío gratis" aria-describedby="free-shipping-minimum-help" />
                            <span>MXN</span>
                        </div>
                        <span id="free-shipping-minimum-help" class="admin-form-help">Los pedidos iguales o superiores a
                            este monto tendrán envío gratis.</span>
                    </label>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const freeShippingToggle = document.querySelector('#free-shipping-toggle input[type="checkbox"]');
        const freeShippingTypeField = document.getElementById('free-shipping-type-field');
        const freeShippingTypeInput = document.getElementById('free-shipping-type');
        const freeShippingAllHelp = document.getElementById('free-shipping-all-help');
        const freeShippingMinimumField = document.getElementById('free-shipping-minimum-field');
        const freeShippingMinimumInput = document.querySelector('input[name="free_shipping_minimum"]');

        const updateFreeShippingField = () => {
            const isEnabled = freeShippingToggle.checked;
            const usesMinimum = freeShippingTypeInput.value === 'minimum';
            const appliesToAll = freeShippingTypeInput.value === 'all';

            freeShippingTypeField.classList.toggle('hidden', !isEnabled);
            freeShippingTypeField.toggleAttribute('aria-hidden', !isEnabled);
            freeShippingAllHelp.classList.toggle('hidden', !isEnabled || !appliesToAll);
            freeShippingAllHelp.toggleAttribute('aria-hidden', !isEnabled || !appliesToAll);
            freeShippingMinimumField.classList.toggle('hidden', !isEnabled || !usesMinimum);
            freeShippingMinimumField.toggleAttribute('aria-hidden', !isEnabled || !usesMinimum);
            freeShippingMinimumInput.required = isEnabled && usesMinimum;

            if (!isEnabled) {
                freeShippingMinimumInput.value = '';
            }
        };

        updateFreeShippingField();
        freeShippingToggle.addEventListener('change', updateFreeShippingField);
        freeShippingTypeInput.addEventListener('change', updateFreeShippingField);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Envíos', 'sectionTitle' => 'Envíos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/shipping.blade.php ENDPATH**/ ?>