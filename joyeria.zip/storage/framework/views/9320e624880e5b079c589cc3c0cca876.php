<?php
    $sizeStatuses = [
        1 => 'Activo',
        0 => 'Inactivo',
    ];
    $isEditing = isset($size->exists) && $size->exists;
    $selectedCategoryIds = collect(old('category_ids', $selectedCategoryIds ?? []))
        ->map(fn ($categoryId): int => (int) $categoryId)
        ->all();
?>

<form id="size-form" method="POST"
    action="<?php echo e($isEditing ? route('sizes.update', $size) : route('sizes.store')); ?>" class="space-y-7">
    <?php echo csrf_field(); ?>

    <?php if($isEditing): ?>
        <?php echo method_field('PATCH'); ?>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Información general','description' => 'Define el nombre, las categorías aplicables y el estado de la talla dentro del catálogo.','id' => 'size-general-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Información general','description' => 'Define el nombre, las categorías aplicables y el estado de la talla dentro del catálogo.','id' => 'size-general-title']); ?>
        <div class="grid gap-5 sm:grid-cols-2">
            <label>
                <span class="admin-form-label admin-form-label-required">Nombre</span>
                <input type="text" name="name" value="<?php echo e(old('name', $size->name)); ?>"
                    placeholder="Ej. 7 o 18 cm" class="admin-form-input" required />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label admin-form-label-required">Estado</span>
                <select name="status" class="admin-form-input" required>
                    <?php $__currentLoopData = $sizeStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"
                            <?php if((string) old('status', $size->status ?? true) === (string) $value): echo 'selected'; endif; ?>>
                            <?php echo e($label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <fieldset class="sm:col-span-2">
                <legend class="admin-form-label">Categorías aplicables</legend>
                <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label class="group relative">
                            <input
                                type="checkbox"
                                name="category_ids[]"
                                value="<?php echo e($category->id); ?>"
                                class="peer sr-only"
                                <?php if(in_array($category->id, $selectedCategoryIds, true)): echo 'checked'; endif; ?>
                            />
                            <span class="aurea-focus flex cursor-pointer items-center gap-3 rounded-xl border border-[#dfe2dc] bg-white px-3.5 py-3 text-sm text-[#59635c] transition hover:border-aurea-gold group-has-[:checked]:border-aurea-gold group-has-[:checked]:bg-[#fbf8f3] group-has-[:focus-visible]:outline group-has-[:focus-visible]:outline-2 group-has-[:focus-visible]:outline-aurea-focus group-has-[:focus-visible]:outline-offset-2">
                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-[#cfd4ce] bg-white text-white transition group-has-[:checked]:border-aurea-gold group-has-[:checked]:bg-aurea-gold">
                                    <svg class="h-3.5 w-3.5 opacity-0 transition group-has-[:checked]:opacity-100" viewBox="0 0 16 16"
                                        fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                        <path d="m3 8 3 3 7-7" />
                                    </svg>
                                </span>
                                <span class="font-medium"><?php echo e($category->name); ?></span>
                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-[#929b94]">No hay categorías activas disponibles.</p>
                    <?php endif; ?>
                </div>
                <span class="admin-form-help">Puedes seleccionar una o varias categorías principales.</span>
                <?php $__errorArgs = ['category_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['category_ids.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
</form>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/sizes/_form.blade.php ENDPATH**/ ?>