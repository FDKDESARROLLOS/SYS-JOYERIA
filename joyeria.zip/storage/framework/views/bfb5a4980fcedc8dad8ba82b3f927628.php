<?php $__env->startSection('content'); ?>
    <?php
        $baseValues = [
            'material' => $productModel->material?->name ?? '—',
            'size' => $productModel->baseSize?->name ?? '—',
            'stone' => $productModel->productStones
                ->pluck('stone.name')
                ->filter()
                ->unique()
                ->implode(', ') ?: '—',
            'karat' => $productModel->karat ? $productModel->karat . 'K' : '—',
            'metal_color' => $productModel->metal_color ?: '—',
            'cost' => $productModel->cost !== null ? '$' . number_format((float) $productModel->cost, 2) . ' MXN' : '—',
            'price' => $productModel->price !== null ? '$' . number_format((float) $productModel->price, 2) . ' MXN' : '—',
            'sale_price' => $productModel->sale_price !== null
                ? '$' . number_format((float) $productModel->sale_price, 2) . ' MXN'
                : '—',
        ];
        $isInherited = fn ($variant, $key): bool => $variant->{$key} === null;
        $effectiveValue = fn ($variant, $key): string => $isInherited($variant, $key)
            ? $baseValues[$key]
            : ($key === 'karat' ? $variant->{$key} . 'K' : (in_array($key, ['cost', 'price', 'sale_price'], true)
                ? '$' . number_format((float) $variant->{$key}, 2) . ' MXN'
                : (string) $variant->{$key}));
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            ['label' => 'Productos', 'url' => route('products.index')],
            ['label' => $product['name'], 'url' => route('products.edit', $productModel)],
            ['label' => 'Variantes', 'url' => null],
        ],'title' => 'Variantes','description' => 'Administra las diferentes versiones comerciales de este producto.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Productos', 'url' => route('products.index')],
            ['label' => $product['name'], 'url' => route('products.edit', $productModel)],
            ['label' => 'Variantes', 'url' => null],
        ]),'title' => 'Variantes','description' => 'Administra las diferentes versiones comerciales de este producto.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.flash-messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.flash-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $attributes = $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $component = $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-context','data' => ['product' => $product,'editUrl' => route('products.edit', $productModel)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-context'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.edit', $productModel))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793)): ?>
<?php $attributes = $__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793; ?>
<?php unset($__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793)): ?>
<?php $component = $__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793; ?>
<?php unset($__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793); ?>
<?php endif; ?>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="variants-list-title">
        <div
            class="flex flex-col justify-between gap-3 border-b border-[#eef0ec] px-5 py-5 sm:flex-row sm:items-center sm:px-6">
            <div>
                <h3 id="variants-list-title" class="font-serif text-xl text-[#28302b]">Variantes del producto</h3>
                <p class="mt-1 text-xs text-[#8a938d]"><?php echo e($productVariants->total()); ?> versiones configuradas</p>
            </div>
            <div class="flex flex-wrap items-center gap-3">
                <p class="text-xs text-[#9ca49e]">El stock se administra desde Inventario.</p>
                <a href="<?php echo e(route('products.variants.create', $productModel)); ?>"
                    class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-3 py-2 text-xs font-medium text-white shadow-sm hover:bg-[#9f793f]">
                    <span class="text-base leading-none">+</span>
                    Nueva variante
                </a>
            </div>
        </div>

        <?php if($productVariants->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay variantes todavía','description' => 'Agrega una variante para definir otra versión comercial del producto.','actionUrl' => route('products.variants.create', $productModel),'actionLabel' => 'Agregar variante']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay variantes todavía','description' => 'Agrega una variante para definir otra versión comercial del producto.','action-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.create', $productModel)),'action-label' => 'Agregar variante']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="hidden overflow-x-auto sm:block">
                <table class="admin-table w-full min-w-220 text-left text-sm">
                    <caption class="sr-only">Variantes de <?php echo e($product['name']); ?></caption>
                    <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                        <tr>
                            <th scope="col" class="px-5 py-3 font-medium sm:px-6">SKU</th>
                            <th scope="col" class="px-3 py-3 font-medium">Talla</th>
                            <th scope="col" class="px-3 py-3 font-medium">Material</th>
                            <th scope="col" class="px-3 py-3 font-medium">Kilataje</th>
                            <th scope="col" class="px-3 py-3 font-medium">Color</th>
                            <th scope="col" class="px-3 py-3 font-medium">Piedra</th>
                            <th scope="col" class="px-3 py-3 font-medium">Precio</th>
                            <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                            <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#f0f1ed]">
                        <?php $__currentLoopData = $productVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                                <td class="px-5 py-4 sm:px-6">
                                    <div class="flex items-center gap-3">
                                        <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $product['imagePath'],'alt' => $product['name'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['imagePath']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['name']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                        <span class="font-medium text-[#343d37]"><?php echo e($variant->sku); ?></span>
                                    </div>
                                </td>
                                <td class="px-3 py-4"><?php echo e($variant->size?->name ?? $baseValues['size']); ?></td>
                                <td class="px-3 py-4"><?php echo e($variant->material?->name ?? $baseValues['material']); ?></td>
                                <td class="px-3 py-4"><?php echo e($effectiveValue($variant, 'karat')); ?></td>
                                <td class="px-3 py-4"><?php echo e($effectiveValue($variant, 'metal_color')); ?></td>
                                <td class="px-3 py-4"><?php echo e($variant->stone?->name ?? $baseValues['stone']); ?></td>
                                <td class="px-3 py-4 font-medium text-[#343d37]"><?php echo e($effectiveValue($variant, 'price')); ?></td>
                                <td class="px-3 py-4">
                                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => match ($variant->status) {
                                            'active' => 'Activo',
                                            'inactive' => 'Inactivo',
                                            default => 'Borrador',
                                        },'statusClass' => match ($variant->status) {
                                            'active' => 'text-[#5b8668]',
                                            'inactive' => 'text-[#a27a3f]',
                                            default => 'text-[#806441]',
                                        }]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match ($variant->status) {
                                            'active' => 'Activo',
                                            'inactive' => 'Inactivo',
                                            default => 'Borrador',
                                        }),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match ($variant->status) {
                                            'active' => 'text-[#5b8668]',
                                            'inactive' => 'text-[#a27a3f]',
                                            default => 'text-[#806441]',
                                        })]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                                </td>
                                <td class="px-5 py-4 text-right sm:px-6">
                                    <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $variant->sku,'editUrl' => route('products.variants.edit', [$productModel, $variant]),'deleteLabel' => 'variante','deleteUrl' => route('products.variants.destroy', [$productModel, $variant])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variant->sku),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.edit', [$productModel, $variant])),'delete-label' => 'variante','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.destroy', [$productModel, $variant]))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="divide-y divide-[#f0f1ed] sm:hidden">
                <?php $__currentLoopData = $productVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="px-5 py-4">
                        <div class="flex items-start justify-between gap-3">
                            <div class="flex min-w-0 items-center gap-3">
                                <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $product['imagePath'],'alt' => $product['name'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['imagePath']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['name']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                <div class="min-w-0">
                                    <p class="text-sm font-medium text-[#343d37]"><?php echo e($variant->sku); ?></p>
                                    <p class="mt-1 text-xs text-[#929b94]">
                                        Talla <?php echo e($variant->size?->name ?? $baseValues['size']); ?> · <?php echo e($effectiveValue($variant, 'metal_color')); ?> · <?php echo e($variant->stone?->name ?? $baseValues['stone']); ?>

                                    </p>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $variant->status === 'active' ? 'Activo' : ($variant->status === 'inactive' ? 'Inactivo' : 'Borrador'),'statusClass' => $variant->status === 'active' ? 'text-[#5b8668]' : ($variant->status === 'inactive' ? 'text-[#a27a3f]' : 'text-[#806441]')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variant->status === 'active' ? 'Activo' : ($variant->status === 'inactive' ? 'Inactivo' : 'Borrador')),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variant->status === 'active' ? 'text-[#5b8668]' : ($variant->status === 'inactive' ? 'text-[#a27a3f]' : 'text-[#806441]'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                        </div>
                        <div class="mt-3 flex items-end justify-between gap-3">
                            <div class="text-sm text-[#343d37]">
                                <span class="font-medium"><?php echo e($effectiveValue($variant, 'price')); ?></span>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $variant->sku,'editUrl' => route('products.variants.edit', [$productModel, $variant]),'deleteLabel' => 'variante','deleteUrl' => route('products.variants.destroy', [$productModel, $variant])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variant->sku),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.edit', [$productModel, $variant])),'delete-label' => 'variante','delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.variants.destroy', [$productModel, $variant]))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="border-t border-[#eef0ec] px-5 py-4 sm:px-6">
                <?php echo e($productVariants->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Variantes', 'sectionTitle' => 'Variantes'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/products/variants/index.blade.php ENDPATH**/ ?>