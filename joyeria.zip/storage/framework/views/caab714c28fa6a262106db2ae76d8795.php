<?php $__env->startSection('content'); ?>
    <?php
        $storeSettings = config('aurea-demo.store_settings', []);
        $timezones = ['America/Mexico_City'];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Datos de la tienda',
                'url' => null,
            ],
        ],'title' => 'Datos de la tienda','description' => 'Configura la información general y comercial que identifica a '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Datos de la tienda',
                'url' => null,
            ],
        ]),'title' => 'Datos de la tienda','description' => 'Configura la información general y comercial que identifica a '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','required' => true]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <button
                type="button"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]"
            >Guardar configuración</button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <form class="space-y-7">
        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Información de la tienda','description' => 'Define el nombre y los datos de contacto principales de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'store-information-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Información de la tienda','description' => 'Define el nombre y los datos de contacto principales de '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'store-information-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <label>
                    <span class="admin-form-label admin-form-label-required">Nombre de la tienda</span>
                    <input
                        type="text"
                        name="store_name"
                        value="<?php echo e($storeSettings['store_name']); ?>"
                        placeholder="Ej. Nombre de la tienda"
                        class="admin-form-input"
                        required
                    />
                </label>
                <label>
                    <span class="admin-form-label">Razón social</span>
                    <input
                        type="text"
                        name="legal_name"
                        value="<?php echo e($storeSettings['legal_name']); ?>"
                        placeholder="Razón social de la tienda"
                        class="admin-form-input"
                    />
                </label>
                <label>
                    <span class="admin-form-label admin-form-label-required">Correo</span>
                    <input
                        type="email"
                        name="email"
                        value="<?php echo e($storeSettings['email']); ?>"
                        placeholder="hola@aureajewelry.com"
                        class="admin-form-input"
                        required
                    />
                </label>
                <label>
                    <span class="admin-form-label">Teléfono</span>
                    <input
                        type="tel"
                        name="phone"
                        value="<?php echo e($storeSettings['phone']); ?>"
                        placeholder="+52 55 0000 0000"
                        class="admin-form-input"
                    />
                </label>
                <label>
                    <span class="admin-form-label">WhatsApp</span>
                    <input
                        type="tel"
                        name="whatsapp"
                        value="<?php echo e($storeSettings['whatsapp']); ?>"
                        placeholder="+52 55 0000 0000"
                        class="admin-form-input"
                    />
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '02','title' => 'Configuración comercial','description' => 'Define los valores base que se mostrarán en las operaciones de la tienda.','id' => 'commercial-settings-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '02','title' => 'Configuración comercial','description' => 'Define los valores base que se mostrarán en las operaciones de la tienda.','id' => 'commercial-settings-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <div>
                    <span class="admin-form-label">Moneda</span>
                    <div class="flex min-h-11 items-center rounded-lg border border-[#dfe2dc] bg-[#fbfbf9] px-3 text-sm text-[#56625a]">
                        Peso mexicano (MXN)
                    </div>
                </div>
                <label>
                    <span class="admin-form-label admin-form-label-required">Zona horaria</span>
                    <select name="timezone" class="admin-form-input" required>
                        <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($timezone); ?>" <?php if($storeSettings['timezone'] === $timezone): echo 'selected'; endif; ?>><?php echo e($timezone); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>
                    <span class="admin-form-label">Impuesto general (%)</span>
                    <input
                        type="number"
                        name="tax_percentage"
                        value="<?php echo e(filled($storeSettings['tax_percentage']) ? number_format((float) $storeSettings['tax_percentage'], 4, '.', '') : ''); ?>"
                        min="0"
                        step="0.0001"
                        inputmode="decimal"
                        class="admin-form-input"
                        aria-describedby="tax-percentage-help"
                    />
                    <span id="tax-percentage-help" class="admin-form-help">Déjalo vacío si la tienda no utiliza un impuesto general.</span>
                </label>
                <label>
                    <span class="admin-form-label">Costo de envío</span>
                    <div class="admin-form-input-prefix">
                        <span>$</span>
                        <input
                            type="number"
                            name="shipping_cost"
                            value="<?php echo e(filled($storeSettings['shipping_cost']) ? number_format((float) $storeSettings['shipping_cost'], 2, '.', '') : ''); ?>"
                            min="0"
                            step="0.01"
                            inputmode="decimal"
                            aria-label="Costo de envío"
                            aria-describedby="shipping-cost-help"
                        />
                        <span>MXN</span>
                    </div>
                    <span id="shipping-cost-help" class="admin-form-help">Déjalo vacío si el costo de envío se definirá posteriormente o no aplica.</span>
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Datos de la tienda', 'sectionTitle' => 'Datos de la tienda'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/store.blade.php ENDPATH**/ ?>