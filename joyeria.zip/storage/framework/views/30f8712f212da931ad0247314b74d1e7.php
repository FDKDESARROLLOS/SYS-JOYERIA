<?php $__env->startSection('content'); ?>
    <?php
        $orders = config('aurea-demo.orders', []);
        $orderStatuses = ['Pendiente', 'Procesando', 'Enviado', 'Entregado', 'Cancelado'];
        $paymentStatuses = ['Pendiente', 'Pagado', 'Reembolsado', 'Fallido'];
        $orderStatusClasses = [
            'Pendiente' => 'text-[#947142]',
            'Procesando' => 'text-[#61758b]',
            'Enviado' => 'text-[#61758b]',
            'Entregado' => 'text-[#5b8668]',
            'Cancelado' => 'text-aurea-danger',
        ];
        $paymentStatusClasses = [
            'Pendiente' => 'text-[#947142]',
            'Pagado' => 'text-[#5b8668]',
            'Reembolsado' => 'text-[#61758b]',
            'Fallido' => 'text-aurea-danger',
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Ventas',
                'url' => null,
            ],
            [
                'label' => 'Pedidos',
                'url' => null,
            ],
        ],'title' => 'Pedidos','description' => 'Consulta y organiza los pedidos recibidos en la tienda '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Ventas',
                'url' => null,
            ],
            [
                'label' => 'Pedidos',
                'url' => null,
            ],
        ]),'title' => 'Pedidos','description' => 'Consulta y organiza los pedidos recibidos en la tienda '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <section
        class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6"
        aria-labelledby="order-filters-title"
    >
        <div class="mb-5">
            <h3 id="order-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar pedidos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Encuentra un pedido por número, cliente o correo electrónico.</p>
        </div>
        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <label class="sm:col-span-2 xl:col-span-1">
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar pedido</span>
                <input
                    type="search"
                    placeholder="Ej. ORD-1001 o Mariana López"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold"
                />
            </label>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['label' => 'Estado del pedido','options' => $orderStatuses]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Estado del pedido','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderStatuses)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['label' => 'Estado de pago','options' => $paymentStatuses]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Estado de pago','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentStatuses)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Fecha</span>
                <input
                    type="date"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none focus:border-aurea-gold"
                />
            </label>
        </div>
    </section>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="orders-list-title"
    >
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="orders-list-title" class="font-serif text-xl text-[#28302b]">Listado de pedidos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Mostrando <?php echo e(count($orders)); ?> pedidos ficticios.</p>
        </div>

        <?php if(empty($orders)): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay pedidos todavía','description' => 'Los pedidos recibidos aparecerán aquí para que puedas darles seguimiento.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay pedidos todavía','description' => 'Los pedidos recibidos aparecerán aquí para que puedas darles seguimiento.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
        <div class="hidden overflow-x-auto sm:block">
            <table class="admin-table w-full min-w-300 text-left text-sm">
                <caption class="sr-only">Listado de pedidos de la tienda</caption>
                <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                    <tr>
                        <th scope="col" class="px-5 py-3 font-medium sm:px-6">Pedido</th>
                        <th scope="col" class="px-3 py-3 font-medium">Cliente</th>
                        <th scope="col" class="px-3 py-3 font-medium">Fecha</th>
                        <th scope="col" class="px-3 py-3 font-medium">Productos</th>
                        <th scope="col" class="px-3 py-3 font-medium">Total</th>
                        <th scope="col" class="px-3 py-3 font-medium">Método de pago</th>
                        <th scope="col" class="px-3 py-3 font-medium">Pago</th>
                        <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                        <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#f0f1ed]">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                            <td class="px-5 py-4 sm:px-6">
                                <p class="font-medium text-[#343d37]"><?php echo e($order['order_number']); ?></p>
                                <p class="mt-1 text-xs text-[#929b94]"><?php echo e($order['customer_email']); ?></p>
                            </td>
                            <td class="px-3 py-4"><?php echo e($order['customer_name']); ?></td>
                            <td class="whitespace-nowrap px-3 py-4 text-xs text-[#68736c]"><?php echo e($order['date']); ?></td>
                            <td class="px-3 py-4"><?php echo e($order['items_count']); ?></td>
                            <td class="whitespace-nowrap px-3 py-4 font-medium text-[#343d37]">
                                $<?php echo e(number_format($order['total'], 2)); ?> MXN
                            </td>
                            <td class="px-3 py-4"><?php echo e($order['payment_method']); ?></td>
                            <td class="px-3 py-4">
                                <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['payment_status'],'statusClass' => $paymentStatusClasses[$order['payment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['payment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentStatusClasses[$order['payment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                            </td>
                            <td class="px-3 py-4">
                                <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['order_status'],'statusClass' => $orderStatusClasses[$order['order_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['order_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderStatusClasses[$order['order_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                            </td>
                            <td class="px-5 py-4 text-right sm:px-6">
                                <a
                                    href="<?php echo e(route('orders.show', ['orderNumber' => $order['order_number']])); ?>"
                                    class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus"
                                >Ver pedido</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="divide-y divide-[#f0f1ed] sm:hidden">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="px-5 py-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-[#343d37]"><?php echo e($order['order_number']); ?></p>
                            <p class="mt-1 text-xs text-[#929b94]"><?php echo e($order['customer_name']); ?></p>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['order_status'],'statusClass' => $orderStatusClasses[$order['order_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['order_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderStatusClasses[$order['order_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                    </div>
                    <dl class="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                        <div>
                            <dt class="text-[#929b94]">Fecha</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($order['date']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Total</dt>
                            <dd class="mt-0.5 font-medium text-[#343d37]">$<?php echo e(number_format($order['total'], 2)); ?> MXN</dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Pago</dt>
                            <dd class="mt-0.5"><?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['payment_status'],'statusClass' => $paymentStatusClasses[$order['payment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['payment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentStatusClasses[$order['payment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Productos</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($order['items_count']); ?></dd>
                        </div>
                    </dl>
                    <p class="mt-3 text-xs text-[#929b94]"><?php echo e($order['customer_email']); ?></p>
                    <div class="mt-3 flex justify-end">
                        <a
                            href="<?php echo e(route('orders.show', ['orderNumber' => $order['order_number']])); ?>"
                            class="aurea-focus rounded-md px-2 py-1.5 text-xs font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus"
                        >Ver pedido</a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Pedidos', 'sectionTitle' => 'Pedidos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/orders/index.blade.php ENDPATH**/ ?>