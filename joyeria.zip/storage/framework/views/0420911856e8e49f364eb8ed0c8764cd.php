<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'value', 'change', 'description', 'iconBackground', 'iconColor', 'iconPath', 'changeStyle']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'value', 'change', 'description', 'iconBackground', 'iconColor', 'iconPath', 'changeStyle']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] dark:bg-[#2d302e]">

    <div class="flex items-start justify-between">

        <div class="flex h-10 w-10 items-center justify-center rounded-xl <?php echo e($iconBackground); ?> <?php echo e($iconColor); ?>">
            <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="<?php echo e($iconPath); ?>" />
            </svg>
        </div>

        
    </div>

    <p class="mt-5 text-sm text-[#7b847e] dark:text-[#aeb4ae]"><?php echo e($title); ?></p>

    <p class="mt-1 text-2xl font-semibold tracking-tight text-[#252a27] dark:text-[#f1eee8]"><?php echo e($value); ?></p>

    <p class="mt-1 text-[11px] text-[#a0a7a2]"><?php echo e($description); ?></p>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/stat-card.blade.php ENDPATH**/ ?>