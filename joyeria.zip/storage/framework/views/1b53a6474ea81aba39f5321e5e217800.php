<?php $__env->startSection('content'); ?>
    <?php
        $dashboard = config('aurea-demo.dashboard', []);
        $monthlySales = $dashboard['monthly_sales'];
        $monthlyValues = $monthlySales['values'];
        $chartWidth = 700;
        $chartHeight = 220;
        $chartTopPadding = 20;
        $chartBottomPadding = 0;
        $monthlyMinimum = min($monthlyValues);
        $monthlyMaximum = max($monthlyValues);
        $monthlyRange = max($monthlyMaximum - $monthlyMinimum, 1);
        $chartPoints = collect($monthlyValues)
            ->values()
            ->map(function ($value, $index) use (
                $chartWidth,
                $chartHeight,
                $chartTopPadding,
                $chartBottomPadding,
                $monthlyMinimum,
                $monthlyRange,
                $monthlyValues,
            ) {
                $lastIndex = count($monthlyValues) - 1;
                $x = $lastIndex > 0 ? ($index * $chartWidth) / $lastIndex : $chartWidth / 2;
                $availableHeight = $chartHeight - $chartTopPadding - $chartBottomPadding;
                $y = $chartTopPadding + (1 - ($value - $monthlyMinimum) / $monthlyRange) * $availableHeight;

                return [
                    'x' => round($x, 2),
                    'y' => round($y, 2),
                ];
            })
            ->all();
        $salesLinePath = collect($chartPoints)
            ->map(function ($point, $index) {
                return ($index === 0 ? 'M' : 'L') . $point['x'] . ' ' . $point['y'];
            })
            ->implode(' ');
        $salesAreaPath = $salesLinePath . " V {$chartHeight} H 0 Z";
        $catalogProducts = collect(config('aurea-demo.catalog_products', []));
        $inventoryStock = collect(config('aurea-demo.inventory_stock', []));
        $orders = collect(config('aurea-demo.orders', []));
        $orderStatusClasses = [
            'Pendiente' => 'text-[#8a7153]',
            'Procesando' => 'text-[#5e7180]',
            'Enviado' => 'text-[#5e7180]',
            'Entregado' => 'text-[#587262]',
            'Cancelado' => 'text-aurea-danger',
        ];
        $metricCards = $dashboard['stats'];
        $recentOrders = collect($dashboard['recent_orders'])
            ->map(function ($orderNumber) use ($orders, $orderStatusClasses) {
                $order = $orders->firstWhere('order_number', $orderNumber);

                if (!$order) {
                    return null;
                }

                return [
                    'number' => $order['order_number'],
                    'customer' => $order['customer_name'],
                    'date' => $order['date'],
                    'total' => '$' . number_format($order['total'], 2) . ' MXN',
                    'status' => $order['order_status'],
                    'statusClass' => $orderStatusClasses[$order['order_status']],
                ];
            })
            ->filter()
            ->values();
        $lowStockProducts = collect($dashboard['low_stock'])
            ->map(function ($sku) use ($inventoryStock, $catalogProducts) {
                $inventoryItem = $inventoryStock->firstWhere('sku', $sku);

                if (!$inventoryItem) {
                    return null;
                }

                $catalogProduct = $catalogProducts->first(function ($product) use ($sku) {
                    return $sku === $product['base_sku'] || str_starts_with($sku, $product['base_sku'] . '-');
                });

                return [
                    'name' => $inventoryItem['product'],
                    'sku' => $inventoryItem['sku'],
                    'stock' => $inventoryItem['current_stock'] . ' unidades',
                    'image' => $catalogProduct['image'] ?? '',
                ];
            })
            ->filter()
            ->values();
        $bestSellingProducts = collect($dashboard['best_sellers'])
            ->map(function ($bestSeller) use ($catalogProducts) {
                $product = $catalogProducts->firstWhere('base_sku', $bestSeller['base_sku']);

                if (!$product) {
                    return null;
                }

                return [
                    'rank' => $bestSeller['rank'],
                    'name' => $product['name'],
                    'collection' => $product['category'],
                    'sold' => $bestSeller['sold'],
                    'price' => $product['price'],
                    'image' => $product['image'],
                ];
            })
            ->filter()
            ->values();
        $visitAnalytics = $dashboard['visit_analytics'];
        $visitValues = $visitAnalytics['last_30_days']['values'];
        $visitChartWidth = 700;
        $visitChartHeight = 220;
        $visitChartTopPadding = 20;
        $visitMinimum = min($visitValues);
        $visitRange = max(max($visitValues) - $visitMinimum, 1);
        $visitChartPoints = collect($visitValues)
            ->values()
            ->map(function ($value, $index) use ($visitChartWidth, $visitChartHeight, $visitChartTopPadding, $visitMinimum, $visitRange, $visitValues) {
                $lastIndex = count($visitValues) - 1;
                $x = $lastIndex > 0 ? ($index * $visitChartWidth) / $lastIndex : $visitChartWidth / 2;
                $availableHeight = $visitChartHeight - $visitChartTopPadding;
                $y = $visitChartTopPadding + (1 - ($value - $visitMinimum) / $visitRange) * $availableHeight;

                return ['x' => round($x, 2), 'y' => round($y, 2)];
            })
            ->all();
        $visitLinePath = collect($visitChartPoints)
            ->map(fn ($point, $index) => ($index === 0 ? 'M' : 'L') . $point['x'] . ' ' . $point['y'])
            ->implode(' ');
        $visitAreaPath = $visitLinePath . " V {$visitChartHeight} H 0 Z";
        $mostVisitedProducts = collect($visitAnalytics['most_visited_products'])
            ->map(function ($mostVisitedProduct) use ($catalogProducts) {
                $product = $catalogProducts->firstWhere('base_sku', $mostVisitedProduct['base_sku']);

                if (!$product) {
                    return null;
                }

                return [
                    'name' => $product['name'],
                    'category' => $product['category'],
                    'image' => $product['image'],
                    'visits' => $mostVisitedProduct['visits'],
                ];
            })
            ->filter()
            ->values();
    ?>

    <div class="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
            <div class="mb-2 flex flex-wrap items-center gap-2">
                <p class="text-sm text-[#8c958f]">Viernes, 02 de octubre de 2026</p>
            </div>
            <h2 class="font-serif text-3xl text-aurea-ink">Buenos días, Admin Prueba</h2>
            <p class="mt-2 text-sm text-aurea-muted">Aquí tienes lo más importante de tu tienda hoy.</p>
        </div>
        <button type="button"
            class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f]">
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <path d="M12 5v14M5 12h14" />
            </svg>
            Añadir producto
        </button>
    </div>

    <section class="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php $__currentLoopData = $metricCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metricCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal3c3cb599308b2d9971dae437d0b6bab6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.stat-card','data' => ['title' => $metricCard['title'],'value' => $metricCard['value'],'change' => $metricCard['change'],'description' => $metricCard['description'],'iconBackground' => $metricCard['iconBackground'],'iconColor' => $metricCard['iconColor'],'iconPath' => $metricCard['iconPath'],'changeStyle' => $metricCard['changeStyle']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['title']),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['value']),'change' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['change']),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['description']),'icon-background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconBackground']),'icon-color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconColor']),'icon-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconPath']),'change-style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['changeStyle'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6)): ?>
<?php $attributes = $__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6; ?>
<?php unset($__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c3cb599308b2d9971dae437d0b6bab6)): ?>
<?php $component = $__componentOriginal3c3cb599308b2d9971dae437d0b6bab6; ?>
<?php unset($__componentOriginal3c3cb599308b2d9971dae437d0b6bab6); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="mt-7" aria-labelledby="visit-analytics-title">
        <div class="mb-4 flex items-end justify-between gap-4">
            <div>
                <h2 id="visit-analytics-title" class="font-serif text-2xl text-[#28302b]">Analítica de visitas</h2>
                <p class="mt-1 text-xs text-[#8a938d]">Una vista general del interés en tu tienda</p>
            </div>
            <span class="hidden text-[10px] uppercase tracking-[.16em] text-[#a0a7a2] sm:block">Datos demo</span>
        </div>

        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <?php $__currentLoopData = $visitAnalytics['stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metricCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal3c3cb599308b2d9971dae437d0b6bab6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.stat-card','data' => ['title' => $metricCard['title'],'value' => $metricCard['value'],'change' => $metricCard['change'],'description' => $metricCard['description'],'iconBackground' => $metricCard['iconBackground'],'iconColor' => $metricCard['iconColor'],'iconPath' => $metricCard['iconPath'],'changeStyle' => $metricCard['changeStyle']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['title']),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['value']),'change' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['change']),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['description']),'icon-background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconBackground']),'icon-color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconColor']),'icon-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['iconPath']),'change-style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($metricCard['changeStyle'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6)): ?>
<?php $attributes = $__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6; ?>
<?php unset($__attributesOriginal3c3cb599308b2d9971dae437d0b6bab6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c3cb599308b2d9971dae437d0b6bab6)): ?>
<?php $component = $__componentOriginal3c3cb599308b2d9971dae437d0b6bab6; ?>
<?php unset($__componentOriginal3c3cb599308b2d9971dae437d0b6bab6); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-4 grid gap-4 xl:grid-cols-[1.65fr_1fr]">
            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6">
                <div class="mb-6">
                    <h3 class="font-serif text-xl text-[#28302b]">Visitas últimos 30 días</h3>
                    <p class="mt-1 text-xs text-[#8a938d]">Tendencia de tráfico en tu tienda</p>
                </div>
                <div class="relative h-56" role="img" aria-label="<?php echo e($visitAnalytics['last_30_days']['description']); ?>">
                    <div class="absolute inset-0 flex flex-col justify-between text-[10px] text-[#b0b6b1]">
                        <span><?php echo e(number_format(max($visitValues))); ?></span>
                        <span><?php echo e(number_format(round(max($visitValues) * .66))); ?></span>
                        <span><?php echo e(number_format(round(max($visitValues) * .33))); ?></span>
                        <span>0</span>
                    </div>
                    <div class="absolute inset-y-0 left-12 right-0 flex flex-col justify-between">
                        <span class="border-t border-dashed border-[#eceee9]"></span>
                        <span class="border-t border-dashed border-[#eceee9]"></span>
                        <span class="border-t border-dashed border-[#eceee9]"></span>
                        <span class="border-t border-[#eceee9]"></span>
                    </div>
                    <svg class="absolute bottom-5 left-12 right-0 h-[calc(100%-20px)] w-[calc(100%-48px)] overflow-visible" viewBox="0 0 700 220" preserveAspectRatio="none" aria-hidden="true">
                        <defs>
                            <linearGradient id="visits-fill" x1="0" x2="0" y1="0" y2="1">
                                <stop offset="0" stop-color="#e8ddcf" stop-opacity=".42" />
                                <stop offset="1" stop-color="#e8ddcf" stop-opacity="0" />
                            </linearGradient>
                        </defs>
                        <path d="<?php echo e($visitAreaPath); ?>" fill="url(#visits-fill)" />
                        <path d="<?php echo e($visitLinePath); ?>" fill="none" stroke="#9a7445" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" vector-effect="non-scaling-stroke" />
                    </svg>
                    <div class="absolute bottom-0 left-12 right-0 flex justify-between text-[10px] text-[#a2aaa4]">
                        <?php $__currentLoopData = $visitAnalytics['last_30_days']['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($label); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>

            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)]">
                <div class="mb-4">
                    <h3 class="font-serif text-xl text-[#28302b]">Productos más visitados</h3>
                    <p class="mt-1 text-xs text-[#8a938d]">Interés durante los últimos 30 días</p>
                </div>
                <?php $__currentLoopData = $mostVisitedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostVisitedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 border-t border-[#f0f1ed] py-3">
                        <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $mostVisitedProduct['image'] ?? null,'alt' => $mostVisitedProduct['name'],'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mostVisitedProduct['image'] ?? null),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mostVisitedProduct['name']),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium text-[#3d4640]"><?php echo e($mostVisitedProduct['name']); ?></p>
                            <p class="mt-0.5 text-[11px] text-[#929b94]"><?php echo e($mostVisitedProduct['category']); ?></p>
                        </div>
                        <span class="text-right text-xs font-medium text-[#414a44]"><?php echo e($mostVisitedProduct['visits']); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </section>

    

    <div class="mt-7 grid gap-7 xl:grid-cols-[1.45fr_1fr]">
        <section
            class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]">
            <div class="flex items-center justify-between border-b border-[#eef0ec] px-5 py-5 sm:px-6">
                <div>
                    <h3 class="font-serif text-xl text-[#28302b]">Pedidos recientes</h3>
                    <p class="mt-1 text-xs text-[#8a938d]">Últimas transacciones de tu tienda</p>
                </div><button type="button"
                    class="aurea-focus rounded-md px-1 text-xs font-medium text-[#aa8046] hover:text-[#80602f]">Ver
                    todos</button>
            </div>

            <div class="hidden overflow-x-auto sm:block">

                <table class="admin-table w-full min-w-140 text-left text-sm">
                    <caption class="sr-only">Pedidos recientes del dashboard</caption>
                    <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                        <tr>
                            <th scope="col" class="px-5 py-3 font-medium sm:px-6">Pedido</th>
                            <th scope="col" class="px-3 py-3 font-medium">Cliente</th>
                            <th scope="col" class="px-3 py-3 font-medium">Fecha</th>
                            <th scope="col" class="px-3 py-3 font-medium">Total</th>
                            <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#f0f1ed]">
                        <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-[#5b655e]">
                                <td class="px-5 py-4 font-medium text-[#343d37] sm:px-6"><?php echo e($recentOrder['number']); ?>

                                </td>

                                <td class="px-3 py-4">
                                    <?php echo e($recentOrder['customer']); ?>

                                </td>

                                <td class="px-3 py-4 text-xs text-[#929b94]">
                                    <?php echo e($recentOrder['date']); ?>

                                </td>

                                <td class="px-3 py-4 font-medium text-[#343d37]">
                                    <?php echo e($recentOrder['total']); ?>

                                </td>

                                <td class="px-3 py-4">
                                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $recentOrder['status'],'statusClass' => $recentOrder['statusClass']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentOrder['status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentOrder['statusClass'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>

            <div class="divide-y divide-[#f0f1ed] sm:hidden">
                <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="px-5 py-4">
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <p class="text-sm font-semibold text-[#343d37]"><?php echo e($recentOrder['number']); ?></p>
                                <p class="mt-1 text-xs text-[#6f7972]"><?php echo e($recentOrder['customer']); ?></p>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $recentOrder['status'],'statusClass' => $recentOrder['statusClass']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentOrder['status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentOrder['statusClass'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                        </div>
                        <div class="mt-3 flex justify-between text-[11px] text-[#929b94]">
                            <span><?php echo e($recentOrder['date']); ?></span><strong
                                class="text-sm font-medium text-[#343d37]"><?php echo e($recentOrder['total']); ?></strong>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <div class="space-y-7">
            <section
                class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)]">
                <div class="mb-4 flex items-center justify-between">
                    <div>
                        <h3 class="font-serif text-xl text-[#28302b]">Stock bajo</h3>
                        <p class="mt-1 text-xs text-[#8a938d]">Productos que necesitan atención</p>
                    </div><button type="button"
                        class="aurea-focus rounded-md px-1 text-xs font-medium text-[#aa8046] hover:text-[#80602f]">Ver
                        inventario</button>
                </div>
                <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowStockProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 border-t border-[#f0f1ed] py-3">
                        <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $lowStockProduct['image'] ?? null,'alt' => $lowStockProduct['name'],'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lowStockProduct['image'] ?? null),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lowStockProduct['name']),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium text-[#3d4640]"><?php echo e($lowStockProduct['name']); ?></p>
                            <p class="mt-0.5 text-[11px] text-[#929b94]"><?php echo e($lowStockProduct['sku']); ?></p>
                        </div><span
                            class="text-right text-[11px] font-medium text-[#a06d5d]"><?php echo e($lowStockProduct['stock']); ?><br><span
                                class="text-[10px] font-normal uppercase tracking-wider">Stock bajo</span></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <section
                class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)]">
                <div class="mb-4 flex items-center justify-between">
                    <div>
                        <h3 class="font-serif text-xl text-[#28302b]">Más vendidos</h3>
                        <p class="mt-1 text-xs text-[#8a938d]">Esta semana</p>
                    </div><button type="button"
                        class="aurea-focus rounded-md px-1 text-xs font-medium text-[#aa8046] hover:text-[#80602f]">Ver
                        catálogo</button>
                </div>
                <?php $__currentLoopData = $bestSellingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestSellingProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 border-t border-[#f0f1ed] py-3"><span
                            class="w-5 text-xs font-semibold text-[#bca071]"><?php echo e($bestSellingProduct['rank']); ?></span>
                        <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $bestSellingProduct['image'] ?? null,'alt' => $bestSellingProduct['name'],'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bestSellingProduct['image'] ?? null),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bestSellingProduct['name']),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium text-[#3d4640]"><?php echo e($bestSellingProduct['name']); ?></p>
                            <p class="mt-0.5 text-[11px] text-[#929b94]"><?php echo e($bestSellingProduct['collection']); ?> ·
                                <?php echo e($bestSellingProduct['sold']); ?></p>
                        </div><span class="text-sm font-medium text-[#414a44]"><?php echo e($bestSellingProduct['price']); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/dashboard.blade.php ENDPATH**/ ?>