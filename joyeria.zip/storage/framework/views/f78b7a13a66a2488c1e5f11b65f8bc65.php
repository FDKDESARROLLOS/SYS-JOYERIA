<?php $__env->startSection('content'); ?>
    <?php
        $orders = config('aurea-demo.orders', []);
        $order = collect($orders)->firstWhere('order_number', request()->route('orderNumber'));
        abort_unless(is_array($order), 404);
        $catalogProducts = collect(config('aurea-demo.catalog_products', []));
        $productImageForSku = fn ($sku) => $catalogProducts->first(
            fn ($product) => $sku === $product['base_sku'] || str_starts_with($sku, $product['base_sku'] . '-')
        )['image'] ?? null;
        $orderStatusClasses = [
            'Pendiente' => 'text-[#947142]',
            'Procesando' => 'text-[#61758b]',
            'Enviado' => 'text-[#61758b]',
            'Entregado' => 'text-[#5b8668]',
            'Cancelado' => 'text-aurea-danger',
        ];
        $paymentStatusClasses = [
            'Pendiente' => 'text-[#947142]',
            'Pagado' => 'text-[#5b8668]',
            'Reembolsado' => 'text-[#61758b]',
            'Fallido' => 'text-aurea-danger',
        ];
        $fulfillmentStatusClasses = [
            'Pendiente de preparación' => 'text-[#947142]',
            'Preparando' => 'text-[#61758b]',
            'Despachado' => 'text-[#61758b]',
            'Entregado' => 'text-[#5b8668]',
            'No aplica' => 'text-[#929b94]',
        ];
        $fulfillment = $order['fulfillment'];
        $canRegisterDispatch = in_array($fulfillment['fulfillment_status'], ['Pendiente de preparación', 'Preparando'], true);
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Pedidos',
                'url' => route('orders.index'),
            ],
            [
                'label' => $order['order_number'],
                'url' => null,
            ],
        ],'title' => 'Pedido '.e($order['order_number']).'','description' => 'Consulta la información del pedido y su resumen comercial.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Pedidos',
                'url' => route('orders.index'),
            ],
            [
                'label' => $order['order_number'],
                'url' => null,
            ],
        ]),'title' => 'Pedido '.e($order['order_number']).'','description' => 'Consulta la información del pedido y su resumen comercial.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a
                href="<?php echo e(route('orders.index')); ?>"
                class="aurea-focus inline-flex items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] hover:border-aurea-gold hover:text-aurea-focus"
            >Volver a pedidos</a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="mb-7 flex flex-wrap items-center gap-4 border-b border-[#eef0ec] pb-5">
        <p class="text-sm text-[#68736c]"><?php echo e($order['date']); ?></p>
        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['order_status'],'statusClass' => $orderStatusClasses[$order['order_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['order_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderStatusClasses[$order['order_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['payment_status'],'statusClass' => $paymentStatusClasses[$order['payment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['payment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentStatusClasses[$order['payment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
    </div>

    <div class="grid items-start gap-7 xl:grid-cols-[minmax(0,1fr)_19rem]">
        <div class="space-y-7">
            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6" aria-labelledby="customer-title">
                <div class="mb-5 border-b border-[#eef0ec] pb-5">
                    <h2 id="customer-title" class="font-serif text-xl text-[#28302b]">Información del cliente</h2>
                </div>
                <dl class="grid gap-5 sm:grid-cols-3">
                    <div>
                        <dt class="text-xs text-[#929b94]">Nombre</dt>
                        <dd class="mt-1 text-sm text-[#343d37]"><?php echo e($order['customer_name']); ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-[#929b94]">Correo</dt>
                        <dd class="mt-1 break-words text-sm text-[#343d37]"><?php echo e($order['customer_email']); ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-[#929b94]">Teléfono</dt>
                        <dd class="mt-1 text-sm text-[#343d37]"><?php echo e($order['customer_phone']); ?></dd>
                    </div>
                </dl>
            </section>

            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6" aria-labelledby="shipping-title">
                <div class="mb-5 border-b border-[#eef0ec] pb-5">
                    <h2 id="shipping-title" class="font-serif text-xl text-[#28302b]">Dirección de envío</h2>
                </div>
                <address class="not-italic text-sm leading-6 text-[#5b655e]">
                    <strong class="font-medium text-[#343d37]"><?php echo e($order['shipping_address']['recipient']); ?></strong><br>
                    <?php echo e($order['shipping_address']['street']); ?> <?php echo e($order['shipping_address']['exterior_number']); ?><?php echo e($order['shipping_address']['interior_number'] ? ', Int. ' . $order['shipping_address']['interior_number'] : ''); ?><br>
                    <?php echo e($order['shipping_address']['neighborhood']); ?><br>
                    <?php echo e($order['shipping_address']['city']); ?>, <?php echo e($order['shipping_address']['state']); ?><br>
                    C.P. <?php echo e($order['shipping_address']['postal_code']); ?>, <?php echo e($order['shipping_address']['country']); ?>

                </address>
            </section>

            <section class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]" aria-labelledby="items-title">
                <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
                    <h2 id="items-title" class="font-serif text-xl text-[#28302b]">Productos</h2>
                </div>
                <div class="hidden overflow-x-auto sm:block">
                    <table class="admin-table w-full min-w-190 text-left text-sm">
                        <caption class="sr-only">Productos del pedido <?php echo e($order['order_number']); ?></caption>
                        <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                            <tr>
                                <th scope="col" class="px-5 py-3 font-medium sm:px-6">Producto</th>
                                <th scope="col" class="px-3 py-3 font-medium">Variante</th>
                                <th scope="col" class="px-3 py-3 font-medium">SKU</th>
                                <th scope="col" class="px-3 py-3 font-medium">Precio</th>
                                <th scope="col" class="px-3 py-3 font-medium">Cantidad</th>
                                <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-[#f0f1ed]">
                            <?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-[#5b655e]">
                                    <td class="px-5 py-4 sm:px-6">
                                        <div class="flex items-center gap-3">
                                            <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $productImageForSku($item['sku']),'alt' => $item['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productImageForSku($item['sku'])),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                            <span class="font-medium text-[#343d37]"><?php echo e($item['product']); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-3 py-4"><?php echo e($item['variant']); ?></td>
                                    <td class="px-3 py-4 text-xs text-[#929b94]"><?php echo e($item['sku']); ?></td>
                                    <td class="whitespace-nowrap px-3 py-4">$<?php echo e(number_format($item['unit_price'], 2)); ?> MXN</td>
                                    <td class="px-3 py-4"><?php echo e($item['quantity']); ?></td>
                                    <td class="whitespace-nowrap px-5 py-4 text-right font-medium text-[#343d37] sm:px-6">$<?php echo e(number_format($item['subtotal'], 2)); ?> MXN</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="divide-y divide-[#f0f1ed] sm:hidden">
                    <?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="px-5 py-4">
                            <div class="flex items-start justify-between gap-3">
                                <div class="flex min-w-0 items-center gap-3">
                                    <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $productImageForSku($item['sku']),'alt' => $item['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productImageForSku($item['sku'])),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                    <div>
                                        <p class="text-sm font-medium text-[#343d37]"><?php echo e($item['product']); ?></p>
                                    <p class="mt-1 text-xs text-[#929b94]"><?php echo e($item['variant']); ?> · <?php echo e($item['sku']); ?></p>
                                    </div>
                                </div>
                                <p class="whitespace-nowrap text-sm font-medium text-[#343d37]">$<?php echo e(number_format($item['subtotal'], 2)); ?> MXN</p>
                            </div>
                            <p class="mt-3 text-xs text-[#68736c]">$<?php echo e(number_format($item['unit_price'], 2)); ?> MXN · Cantidad <?php echo e($item['quantity']); ?></p>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6" aria-labelledby="fulfillment-title">
                <div class="mb-5 flex flex-col justify-between gap-4 border-b border-[#eef0ec] pb-5 sm:flex-row sm:items-start">
                    <div>
                        <h2 id="fulfillment-title" class="font-serif text-xl text-[#28302b]">Despacho</h2>
                        <p class="mt-1 text-xs text-[#8a938d]">Consulta la preparación y el envío de este pedido.</p>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $fulfillment['fulfillment_status'],'statusClass' => $fulfillmentStatusClasses[$fulfillment['fulfillment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fulfillment['fulfillment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fulfillmentStatusClasses[$fulfillment['fulfillment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                </div>
                <?php if($fulfillment['fulfillment_status'] === 'No aplica'): ?>
                    <p class="text-sm leading-6 text-[#68736c]">
                        Este pedido fue cancelado antes del despacho y no requiere envío.
                    </p>
                <?php elseif($canRegisterDispatch): ?>
                    <div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                        <p class="max-w-xl text-sm leading-6 text-[#68736c]">
                            <?php echo e($fulfillment['fulfillment_status'] === 'Preparando' ? 'El pedido está en preparación y listo para completar sus datos de despacho.' : 'Este pedido todavía no cuenta con un registro de despacho.'); ?>

                        </p>
                        <a
                            href="<?php echo e(route('orders.dispatch', ['orderNumber' => $order['order_number']])); ?>"
                            class="aurea-focus inline-flex w-fit items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]"
                        >Registrar despacho</a>
                    </div>
                <?php else: ?>
                    <dl class="grid gap-x-5 gap-y-5 sm:grid-cols-2">
                        <div>
                            <dt class="text-xs text-[#929b94]">Paquetería</dt>
                            <dd class="mt-1 text-sm text-[#343d37]"><?php echo e($fulfillment['carrier']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-[#929b94]">Número de guía</dt>
                            <dd class="mt-1 text-sm text-[#343d37]"><?php echo e($fulfillment['tracking_number']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-[#929b94]">Fecha de envío</dt>
                            <dd class="mt-1 text-sm text-[#343d37]"><?php echo e(\Illuminate\Support\Carbon::parse($fulfillment['shipped_at'])->locale('es')->translatedFormat('d M Y')); ?></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-[#929b94]">Entrega estimada</dt>
                            <dd class="mt-1 text-sm text-[#343d37]"><?php echo e(\Illuminate\Support\Carbon::parse($fulfillment['estimated_delivery'])->locale('es')->translatedFormat('d M Y')); ?></dd>
                        </div>
                        <?php if($fulfillment['shipping_notes']): ?>
                            <div class="sm:col-span-2">
                                <dt class="text-xs text-[#929b94]">Notas</dt>
                                <dd class="mt-1 text-sm leading-6 text-[#5b655e]"><?php echo e($fulfillment['shipping_notes']); ?></dd>
                            </div>
                        <?php endif; ?>
                    </dl>
                <?php endif; ?>
            </section>
        </div>

        <aside class="space-y-7 lg:sticky lg:top-7">
            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)]" aria-labelledby="summary-title">
                <h2 id="summary-title" class="font-serif text-xl text-[#28302b]">Resumen del pedido</h2>
                <dl class="mt-5 space-y-3 text-sm">
                    <div class="flex justify-between gap-4 text-[#68736c]"><dt>Subtotal</dt><dd>$<?php echo e(number_format($order['subtotal'], 2)); ?> MXN</dd></div>
                    <div class="flex justify-between gap-4 text-[#68736c]"><dt>Envío</dt><dd>$<?php echo e(number_format($order['shipping_cost'], 2)); ?> MXN</dd></div>
                    <div class="flex justify-between gap-4 text-[#68736c]"><dt>Impuestos</dt><dd>$<?php echo e(number_format($order['tax'], 2)); ?> MXN</dd></div>
                    <div class="flex justify-between gap-4 border-t border-[#eef0ec] pt-4 text-base font-semibold text-[#343d37]"><dt>Total</dt><dd>$<?php echo e(number_format($order['total'], 2)); ?> MXN</dd></div>
                </dl>
            </section>

            <section class="rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)]" aria-labelledby="payment-title">
                <h2 id="payment-title" class="font-serif text-xl text-[#28302b]">Pago</h2>
                <dl class="mt-5 space-y-4 text-sm">
                    <div><dt class="text-xs text-[#929b94]">Método</dt><dd class="mt-1 text-[#343d37]"><?php echo e($order['payment_method']); ?></dd></div>
                    <div><dt class="text-xs text-[#929b94]">Estado</dt><dd class="mt-1"><?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $order['payment_status'],'statusClass' => $paymentStatusClasses[$order['payment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['payment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentStatusClasses[$order['payment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?></dd></div>
                    <?php if($order['payment_reference']): ?>
                        <div><dt class="text-xs text-[#929b94]">Referencia</dt><dd class="mt-1 text-xs text-[#5b655e]"><?php echo e($order['payment_reference']); ?></dd></div>
                    <?php endif; ?>
                </dl>
            </section>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Pedido', 'sectionTitle' => 'Pedido'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/orders/show.blade.php ENDPATH**/ ?>