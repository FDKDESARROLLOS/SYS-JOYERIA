<?php
    $isEditing = $isEditing ?? false;
    $variantStatuses = [
        'active' => 'Activo',
        'draft' => 'Borrador',
        'inactive' => 'Inactivo',
    ];
    $selectedSizeId = old('size_id', $variant->size_id);
    $selectedMaterialId = old('material_id', $variant->material_id);
    $selectedStoneId = old('stone_id', $variant->stone_id);
    $selectedKarat = old('karat', $variant->karat);
    $selectedMetalColor = old('metal_color', $variant->metal_color);
    $selectedStatus = old('status', $variant->status ?: 'active');
    $baseMaterialName = $productModel->material?->name;
    $baseSizeName = $productModel->baseSize?->name;
    $baseStoneIds = $baseStoneIds ?? collect();

    if ((string) $selectedSizeId === (string) $productModel->base_size_id) {
        $selectedSizeId = null;
    }

    if ((string) $selectedMaterialId === (string) $productModel->material_id) {
        $selectedMaterialId = null;
    }

    if ($selectedKarat !== null && (int) $selectedKarat === (int) $productModel->karat) {
        $selectedKarat = null;
    }

    if ($selectedMetalColor !== null && $selectedMetalColor === $productModel->metal_color) {
        $selectedMetalColor = null;
    }

    if ($selectedStoneId !== null && $baseStoneIds->contains((int) $selectedStoneId)) {
        $selectedStoneId = null;
    }

    $inheritedCost = $productModel->cost !== null ? '$'.number_format((float) $productModel->cost, 2). ' MXN' : 'sin valor base';
    $inheritedPrice = $productModel->price !== null ? '$'.number_format((float) $productModel->price, 2). ' MXN' : 'sin valor base';
    $inheritedSalePrice = $productModel->sale_price !== null ? '$'.number_format((float) $productModel->sale_price, 2). ' MXN' : 'sin valor base';
    $formAction = $isEditing
        ? route('products.variants.update', [$productModel, $variant])
        : route('products.variants.store', $productModel);
?>

<form id="variant-form" method="POST" action="<?php echo e($formAction); ?>">
    <?php echo csrf_field(); ?>
    <?php if($isEditing): ?>
        <?php echo method_field('PATCH'); ?>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
            <p class="font-medium">Revisa los datos de la variante.</p>
            <ul class="mt-1 list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Datos de la variante','description' => 'Define la versión comercial y los atributos que pueden cambiar respecto al producto.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Datos de la variante','description' => 'Define la versión comercial y los atributos que pueden cambiar respecto al producto.']); ?>
        <div class="mb-5 rounded-lg border border-[#ece8dd] bg-[#fcfaf5] px-4 py-3 text-sm text-[#68736c]">
            <strong class="font-medium text-[#343d37]">Herencia:</strong>
            un campo vacío hereda el valor del producto; un valor seleccionado lo sobrescribe.
        </div>
        <div class="grid gap-5 sm:grid-cols-2">
            <div>
                <span class="admin-form-label">SKU de inventario</span>
                <div class="admin-form-input flex items-center bg-[#fbfbf9] text-[#68736c]" aria-live="polite">
                    <?php echo e($isEditing ? $variant->sku : 'Se generará automáticamente al guardar'); ?>

                </div>
                <p class="admin-form-help">Se genera en backend a partir del SKU base y los atributos de la variante.</p>
            </div>

            <label>
                <span class="admin-form-label">Talla</span>
                <select name="size_id" class="admin-form-input">
                    <option value="">
                        <?php echo e($baseSizeName ? 'Usar talla de referencia ('.$baseSizeName.')' : 'Sin talla específica / Usar talla de referencia'); ?>

                    </option>
                    <?php $__currentLoopData = $applicableSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size->id); ?>" <?php if((string) $selectedSizeId === (string) $size->id): echo 'selected'; endif; ?>>
                            <?php echo e($size->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="admin-form-help">Solo se muestran tallas aplicables a la categoría del producto.</span>
                <?php $__errorArgs = ['size_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label">Material</span>
                <select name="material_id" class="admin-form-input">
                    <option value="">Usar material del producto<?php echo e($baseMaterialName ? ' ('.$baseMaterialName.')' : ''); ?></option>
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($material->id); ?>" <?php if((string) $selectedMaterialId === (string) $material->id): echo 'selected'; endif; ?>>
                            <?php echo e($material->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="admin-form-help">Déjalo vacío para usar el material del producto.</span>
                <?php $__errorArgs = ['material_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label">Kilataje del material</span>
                <select name="karat" class="admin-form-input">
                    <option value="">Usar kilataje del producto<?php echo e($productModel->karat !== null ? ' ('.$productModel->karat.'K)' : ''); ?></option>
                    <?php $__currentLoopData = $karatOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if((string) $selectedKarat === (string) $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="admin-form-help">Déjalo vacío para usar el kilataje del producto.</span>
                <?php $__errorArgs = ['karat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label">Color del metal</span>
                <select name="metal_color" class="admin-form-input">
                    <option value="">Usar color del producto<?php echo e(filled($productModel->metal_color) ? ' ('.$productModel->metal_color.')' : ''); ?></option>
                    <?php $__currentLoopData = $metalColorOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metalColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($metalColor); ?>" <?php if($selectedMetalColor === $metalColor): echo 'selected'; endif; ?>><?php echo e($metalColor); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="admin-form-help">Déjalo vacío para usar el color del producto.</span>
                <?php $__errorArgs = ['metal_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label">Piedra</span>
                <select name="stone_id" class="admin-form-input">
                    <option value="">Usar configuración de piedra del producto</option>
                    <?php $__currentLoopData = $stones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($stone->id); ?>" <?php if((string) $selectedStoneId === (string) $stone->id): echo 'selected'; endif; ?>>
                            <?php echo e($stone->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="admin-form-help">La piedra puede cambiar el precio de esta variante.</span>
                <?php $__errorArgs = ['stone_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

    <div class="mt-7">
        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '02','title' => 'Precio y estado','description' => 'Configura los valores comerciales y la disponibilidad de esta versión.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '02','title' => 'Precio y estado','description' => 'Configura los valores comerciales y la disponibilidad de esta versión.']); ?>
            <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
                <label>
                    <span class="admin-form-label">Costo</span>
                    <div class="admin-form-input-prefix">
                        <span>$</span>
                        <input type="number" name="cost" value="<?php echo e(old('cost', $variant->cost)); ?>" min="0" step="0.01" inputmode="decimal" placeholder="Usar costo base (<?php echo e($inheritedCost); ?>)" aria-label="Costo de variante" />
                    </div>
                    <span class="admin-form-help">Vacío para usar el costo base.</span>
                    <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label>
                    <span class="admin-form-label">Precio</span>
                    <div class="admin-form-input-prefix">
                        <span>$</span>
                        <input type="number" name="price" value="<?php echo e(old('price', $variant->price)); ?>" min="0" step="0.01" inputmode="decimal" placeholder="Usar precio base (<?php echo e($inheritedPrice); ?>)" aria-label="Precio de variante" />
                    </div>
                    <span class="admin-form-help">Vacío para usar el precio base.</span>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label>
                    <span class="admin-form-label">Precio de oferta</span>
                    <div class="admin-form-input-prefix">
                        <span>$</span>
                        <input type="number" name="sale_price" value="<?php echo e(old('sale_price', $variant->sale_price)); ?>" min="0" step="0.01" inputmode="decimal" placeholder="Usar oferta del producto (<?php echo e($inheritedSalePrice); ?>)" aria-label="Precio de oferta de variante" />
                    </div>
                    <span class="admin-form-help">Vacío para usar la oferta del producto.</span>
                    <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label>
                    <span class="admin-form-label admin-form-label-required">Estado</span>
                    <select name="status" class="admin-form-input" required>
                        <?php $__currentLoopData = $variantStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($selectedStatus === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>

            <div class="mt-6 flex flex-wrap justify-end gap-2 border-t border-[#eef0ec] pt-5">
                <a
                    href="<?php echo e(route('products.variants.index', $productModel)); ?>"
                    class="aurea-focus inline-flex items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] hover:border-aurea-gold hover:text-aurea-focus"
                >Cancelar</a>
                <button
                    type="submit"
                    class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]"
                ><?php echo e($isEditing ? 'Guardar cambios' : 'Guardar variante'); ?></button>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
    </div>
</form>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/products/variants/_form.blade.php ENDPATH**/ ?>