<?php $__env->startSection('content'); ?>
    <div>
        <p class="text-[10px] font-semibold uppercase tracking-[.22em] text-aurea-focus">Acceso administrativo</p>
        <h2 id="auth-title" class="mt-3 font-brand text-4xl text-[#222222]">Iniciar sesión</h2>
        <p class="mt-3 text-sm leading-6 text-aurea-muted">Ingresa tus datos para acceder al panel administrativo.</p>
    </div>
    <form method="POST" action="<?php echo e(route('login.store')); ?>" class="mt-8 space-y-5"
        aria-label="Inicio de sesión administrativo">

        <?php echo csrf_field(); ?>

        <label class="block">
            <span class="admin-form-label">Correo electrónico</span>

            <input type="email" name="email" autocomplete="email" placeholder="nombre@tienda.com"
                value="<?php echo e(old('email')); ?>" class="admin-form-input aurea-focus" required />

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['id' => 'login-password','name' => 'password','label' => 'Contraseña','autocomplete' => 'current-password','placeholder' => 'Ingresa tu contraseña']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'login-password','name' => 'password','label' => 'Contraseña','autocomplete' => 'current-password','placeholder' => 'Ingresa tu contraseña']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>

        <div class="flex items-center justify-between gap-4 pt-1">
            <label class="flex cursor-pointer items-center gap-2 text-xs text-aurea-muted">
                <input type="checkbox" name="remember"
                    class="h-4 w-4 rounded border-[#d9d0c5] text-aurea-gold accent-[#b08a57] focus:ring-aurea-gold-soft" />
                Recordarme
            </label>

            <a href="<?php echo e(route('password.request')); ?>"
                class="aurea-focus rounded text-xs font-medium text-aurea-focus hover:text-[#6f5230]">
                ¿Olvidaste tu contraseña?
            </a>
        </div>

        <button type="submit"
            class="aurea-focus inline-flex w-full cursor-pointer items-center justify-center rounded-lg bg-aurea-gold px-4 py-3 text-sm font-medium text-white shadow-sm hover:bg-[#966f3f]">
            Iniciar sesión
        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Iniciar sesión'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/auth/login.blade.php ENDPATH**/ ?>