<?php
    $adminUserRoles = [
        'admin' => 'Administrador',
        'technical' => 'Equipo técnico',
    ];

    $adminUserStatuses = [
        1 => 'Activo',
        0 => 'Inactivo',
    ];

    $formUser = $user ?? null;
?>

<form id="admin-user-form" method="POST"
    action="<?php echo e($isEditing ? route('settings.admin-users.update', $formUser) : route('settings.admin-users.store')); ?>"
    class="space-y-7">
    <?php echo csrf_field(); ?>

    <?php if($isEditing): ?>
        <?php echo method_field('PATCH'); ?>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Información del usuario','description' => 'Define los datos básicos y el nivel de acceso del usuario administrativo.','id' => 'admin-user-information-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Información del usuario','description' => 'Define los datos básicos y el nivel de acceso del usuario administrativo.','id' => 'admin-user-information-title']); ?>
        <div class="grid gap-5 sm:grid-cols-2">

            <label>
                <span class="admin-form-label admin-form-label-required">
                    Nombre
                </span>

                <input type="text" name="name" value="<?php echo e(old('name', $formUser?->name)); ?>"
                    placeholder="Ej. Administrador" class="admin-form-input" required />

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label admin-form-label-required">
                    Correo
                </span>

                <input type="email" name="email" value="<?php echo e(old('email', $formUser?->email)); ?>"
                    placeholder="nombre@tienda.com" class="admin-form-input" required />

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label admin-form-label-required">
                    Rol
                </span>

                <select name="role" class="admin-form-input" required>
                    <?php $__currentLoopData = $adminUserRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(old('role', $formUser?->role) === $value): echo 'selected'; endif; ?>>
                            <?php echo e($label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label admin-form-label-required">
                    Estado
                </span>

                <select name="status" class="admin-form-input" required>
                    <?php $__currentLoopData = $adminUserStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if((string) old('status', $formUser?->status ?? 1) === (string) $value): echo 'selected'; endif; ?>>
                            <?php echo e($label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '02','title' => 'Contraseña','description' => ''.e($isEditing
            ? 'Deja estos campos vacíos si no deseas cambiar la contraseña.'
            : 'Define la contraseña inicial del usuario administrativo.').'','id' => 'admin-user-password-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '02','title' => 'Contraseña','description' => ''.e($isEditing
            ? 'Deja estos campos vacíos si no deseas cambiar la contraseña.'
            : 'Define la contraseña inicial del usuario administrativo.').'','id' => 'admin-user-password-title']); ?>
        <div class="grid gap-5 sm:grid-cols-2">

            <label>
                <span class="admin-form-label <?php echo e($isEditing ? '' : 'admin-form-label-required'); ?>">
                    <?php echo e($isEditing ? 'Nueva contraseña' : 'Contraseña'); ?>

                </span>

                <input type="password" name="password" autocomplete="new-password" class="admin-form-input"
                    <?php if(!$isEditing): echo 'required'; endif; ?> />

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label <?php echo e($isEditing ? '' : 'admin-form-label-required'); ?>">
                    <?php echo e($isEditing ? 'Confirmar nueva contraseña' : 'Confirmar contraseña'); ?>

                </span>

                <input type="password" name="password_confirmation" autocomplete="new-password" class="admin-form-input"
                    <?php if(!$isEditing): echo 'required'; endif; ?> />
            </label>

        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
</form>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/admin-users/_form.blade.php ENDPATH**/ ?>