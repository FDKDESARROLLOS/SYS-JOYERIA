<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'image' => null,
    'alt' => 'Producto',
    'size' => 'sm',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'image' => null,
    'alt' => 'Producto',
    'size' => 'sm',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $hasImage = filled($image) && file_exists(public_path($image));
    $sizeClasses = [
        'xs' => 'h-9 w-9',
        'sm' => 'h-10 w-10',
    ];
?>

<span
    class="<?php echo e($sizeClasses[$size] ?? $sizeClasses['sm']); ?> flex shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#e7e2da] bg-[#f7f5f1] text-[#a39a8e] dark:border-[#4b4a45] dark:bg-[#343633] dark:text-[#aeb4ae]"
    aria-hidden="true"
>
    <?php if($hasImage): ?>
        <img src="<?php echo e(asset($image)); ?>" alt="<?php echo e($alt); ?>" class="h-full w-full object-cover" loading="lazy" />
    <?php else: ?>
        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <rect x="3.5" y="4.5" width="17" height="15" rx="2" />
            <circle cx="8.5" cy="9" r="1.25" />
            <path d="m5.5 17 4.5-4 3 2.5 2-2 3.5 3.5" />
        </svg>
    <?php endif; ?>
</span>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/product-thumbnail.blade.php ENDPATH**/ ?>