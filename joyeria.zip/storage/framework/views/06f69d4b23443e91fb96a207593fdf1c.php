<?php $__env->startSection('content'); ?>
    <?php
        $errorLogs = collect(config('aurea-demo.error_logs', []));
        $logModules = $errorLogs->pluck('module')->unique()->values()->all();
        $logSources = [
            'admin' => 'Administrador',
            'storefront' => 'Tienda',
            'system' => 'Sistema',
        ];
        $logStatuses = ['Pendiente', 'Revisado', 'Resuelto', 'Ignorado'];
        $logStatusClasses = [
            'Pendiente' => 'text-[#a46255]',
            'Revisado' => 'text-[#9a7445]',
            'Resuelto' => 'text-[#587262]',
            'Ignorado' => 'text-[#78716c]',
        ];
        $logCounts = [
            'total' => $errorLogs->count(),
            'pending' => $errorLogs->where('status', 'Pendiente')->count(),
            'reviewed' => $errorLogs->where('status', 'Revisado')->count(),
            'resolved' => $errorLogs->where('status', 'Resuelto')->count(),
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Errores del sistema',
                'url' => route('settings.errors'),
            ],
            [
                'label' => 'Registro de errores',
                'url' => null,
            ],
        ],'title' => 'Registro de errores','description' => 'Consulta los errores internos registrados por el sistema.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Configuración',
                'url' => null,
            ],
            [
                'label' => 'Errores del sistema',
                'url' => route('settings.errors'),
            ],
            [
                'label' => 'Registro de errores',
                'url' => null,
            ],
        ]),'title' => 'Registro de errores','description' => 'Consulta los errores internos registrados por el sistema.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <section class="mb-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Resumen del registro de errores">
        <?php $__currentLoopData = [
            ['label' => 'Total', 'value' => $logCounts['total']],
            ['label' => 'Pendientes', 'value' => $logCounts['pending']],
            ['label' => 'Revisados', 'value' => $logCounts['reviewed']],
            ['label' => 'Resueltos', 'value' => $logCounts['resolved']],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-xl border border-aurea-border bg-aurea-surface px-4 py-4">
                <p class="text-[11px] uppercase tracking-[.14em] text-aurea-muted"><?php echo e($summary['label']); ?></p>
                <p class="mt-2 text-2xl font-semibold tracking-tight text-aurea-ink"><?php echo e($summary['value']); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section data-filter-section class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6" aria-labelledby="log-filters-title">
        <div class="mb-5 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
            <div>
            <h3 id="log-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar registro</h3>
            <p class="mt-1 text-xs text-aurea-muted">Busca un error por código, origen, módulo, usuario o mensaje.</p>
            </div>
            <button type="button" data-clear-filters class="aurea-focus inline-flex w-fit cursor-pointer items-center rounded-md px-2 py-1.5 text-xs font-medium text-aurea-focus hover:bg-aurea-paper">Limpiar filtros</button>
        </div>
        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <label class="sm:col-span-2 xl:col-span-1">
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar error</span>
                <input id="log-search" type="search" placeholder="Ej. PROD-002 o stock" class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold" />
            </label>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['id' => 'log-module-filter','name' => 'log_module','label' => 'Módulo','options' => $logModules]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'log-module-filter','name' => 'log_module','label' => 'Módulo','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($logModules)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <label for="log-source-filter">
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Origen</span>
                <select id="log-source-filter" name="log_source" class="aurea-focus w-full appearance-none rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none hover:border-aurea-gold-soft">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $logSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sourceValue => $sourceLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sourceValue); ?>"><?php echo e($sourceLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['id' => 'log-status-filter','name' => 'log_status','label' => 'Estado','options' => $logStatuses]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'log-status-filter','name' => 'log_status','label' => 'Estado','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($logStatuses)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Fecha desde</span>
                <input id="log-date-filter" type="date" class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none focus:border-aurea-gold" />
            </label>
        </div>
    </section>

    <section class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]" aria-labelledby="log-list-title">
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="log-list-title" class="font-serif text-xl text-[#28302b]">Errores registrados</h3>
            <p class="mt-1 text-xs text-aurea-muted">Los detalles técnicos son únicamente para administración.</p>
        </div>

        <?php if($errorLogs->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay errores registrados.','description' => 'Los errores internos aparecerán aquí cuando exista logging real.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay errores registrados.','description' => 'Los errores internos aparecerán aquí cuando exista logging real.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="hidden overflow-x-auto sm:block">
                <table class="admin-table w-full min-w-320 text-left text-sm">
                    <caption class="sr-only">Registro de errores internos</caption>
                    <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                        <tr>
                            <th scope="col" class="px-5 py-3 font-medium sm:px-6">Fecha</th>
                            <th scope="col" class="px-3 py-3 font-medium">Código</th>
                            <th scope="col" class="px-3 py-3 font-medium">Origen</th>
                            <th scope="col" class="px-3 py-3 font-medium">Módulo</th>
                            <th scope="col" class="px-3 py-3 font-medium">Acción</th>
                            <th scope="col" class="px-3 py-3 font-medium">Usuario</th>
                            <th scope="col" class="px-3 py-3 font-medium">Mensaje</th>
                            <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                            <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acción</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#f0f1ed]">
                        <?php $__currentLoopData = $errorLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="log-row text-[#5b655e] hover:bg-[#fbfbf9]" data-search="<?php echo e(strtolower($log['code'] . ' ' . $log['module'] . ' ' . $log['action'] . ' ' . $log['user'] . ' ' . $log['message'])); ?>" data-source="<?php echo e($log['source']); ?>" data-module="<?php echo e($log['module']); ?>" data-status="<?php echo e($log['status']); ?>" data-date="<?php echo e(\Illuminate\Support\Carbon::parse($log['date'])->format('Y-m-d')); ?>">
                                <td class="whitespace-nowrap px-5 py-4 text-xs text-[#68736c] sm:px-6"><?php echo e($log['date']); ?></td>
                                <td class="px-3 py-4 font-mono text-xs font-medium text-[#4f4a45]"><?php echo e($log['code']); ?></td>
                                <td class="px-3 py-4 text-xs font-medium text-[#5b655e]"><?php echo e($logSources[$log['source']] ?? $log['source']); ?></td>
                                <td class="px-3 py-4"><?php echo e($log['module']); ?></td>
                                <td class="px-3 py-4"><?php echo e($log['action']); ?></td>
                                <td class="px-3 py-4"><?php echo e($log['user']); ?></td>
                                <td class="max-w-xs px-3 py-4 text-xs"><?php echo e($log['message']); ?></td>
                                <td class="px-3 py-4"><span class="<?php echo e($logStatusClasses[$log['status']] ?? 'text-aurea-muted'); ?>" aria-label="Estado: <?php echo e($log['status']); ?>"><?php echo e($log['status']); ?></span></td>
                                <td class="px-5 py-4 text-right sm:px-6">
                                    <button type="button" class="log-detail-trigger aurea-focus cursor-pointer rounded-md px-2 py-1.5 text-xs font-medium text-aurea-focus hover:bg-aurea-paper" data-code="<?php echo e($log['code']); ?>" data-date="<?php echo e($log['date']); ?>" data-source="<?php echo e($logSources[$log['source']] ?? $log['source']); ?>" data-module="<?php echo e($log['module']); ?>" data-action="<?php echo e($log['action']); ?>" data-user="<?php echo e($log['user']); ?>" data-route="<?php echo e($log['route']); ?>" data-entity="<?php echo e($log['entity']); ?>" data-message="<?php echo e($log['message']); ?>" data-detail="<?php echo e($log['internal_detail']); ?>" data-exception="<?php echo e($log['exception']); ?>" data-file="<?php echo e($log['file']); ?>" data-line="<?php echo e($log['line']); ?>" data-status="<?php echo e($log['status']); ?>" data-product="<?php echo e($log['product_context']['product'] ?? ''); ?>" data-sku="<?php echo e($log['product_context']['sku'] ?? ''); ?>" data-selection="<?php echo e($log['product_context']['selection'] ?? ''); ?>" aria-label="Ver detalle de <?php echo e($log['code']); ?>" title="Ver detalle">Ver</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="divide-y divide-[#f0f1ed] sm:hidden">
                <?php $__currentLoopData = $errorLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="log-row px-5 py-4" data-search="<?php echo e(strtolower($log['code'] . ' ' . $log['module'] . ' ' . $log['action'] . ' ' . $log['user'] . ' ' . $log['message'])); ?>" data-source="<?php echo e($log['source']); ?>" data-module="<?php echo e($log['module']); ?>" data-status="<?php echo e($log['status']); ?>" data-date="<?php echo e(\Illuminate\Support\Carbon::parse($log['date'])->format('Y-m-d')); ?>">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <p class="font-mono text-xs font-medium text-[#4f4a45]"><?php echo e($log['code']); ?></p>
                                <p class="mt-1 text-sm font-medium text-[#343d37]"><?php echo e($log['action']); ?></p>
                                <p class="mt-1 text-xs text-aurea-muted"><?php echo e($log['date']); ?> · <?php echo e($logSources[$log['source']] ?? $log['source']); ?> · <?php echo e($log['module']); ?></p>
                            </div>
                            <span class="shrink-0 <?php echo e($logStatusClasses[$log['status']] ?? 'text-aurea-muted'); ?> text-xs"><?php echo e($log['status']); ?></span>
                        </div>
                        <div class="mt-3 flex items-center justify-between gap-3 text-xs text-aurea-muted">
                            <span class="truncate"><?php echo e($log['message']); ?></span>
                            <button type="button" class="log-detail-trigger aurea-focus cursor-pointer rounded-md px-2 py-1.5 font-medium text-aurea-focus hover:bg-aurea-paper" data-code="<?php echo e($log['code']); ?>" data-date="<?php echo e($log['date']); ?>" data-source="<?php echo e($logSources[$log['source']] ?? $log['source']); ?>" data-module="<?php echo e($log['module']); ?>" data-action="<?php echo e($log['action']); ?>" data-user="<?php echo e($log['user']); ?>" data-route="<?php echo e($log['route']); ?>" data-entity="<?php echo e($log['entity']); ?>" data-message="<?php echo e($log['message']); ?>" data-detail="<?php echo e($log['internal_detail']); ?>" data-exception="<?php echo e($log['exception']); ?>" data-file="<?php echo e($log['file']); ?>" data-line="<?php echo e($log['line']); ?>" data-status="<?php echo e($log['status']); ?>" data-product="<?php echo e($log['product_context']['product'] ?? ''); ?>" data-sku="<?php echo e($log['product_context']['sku'] ?? ''); ?>" data-selection="<?php echo e($log['product_context']['selection'] ?? ''); ?>" aria-label="Ver detalle de <?php echo e($log['code']); ?>" title="Ver detalle">Ver</button>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p id="log-no-results" class="hidden px-6 py-10 text-center text-sm text-aurea-muted">No encontramos resultados para los filtros seleccionados.</p>
        <?php endif; ?>
    </section>

    <div id="log-detail-modal" class="fixed inset-0 z-50 hidden items-center justify-center overflow-y-auto bg-[#222222]/25 px-5 py-6 backdrop-blur-sm" role="presentation">
        <div class="my-auto w-full max-w-2xl rounded-2xl border border-aurea-border bg-white p-6 shadow-[0_18px_50px_rgba(35,42,37,0.16)]" role="dialog" aria-modal="true" aria-labelledby="log-detail-title">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <p id="log-detail-code" class="font-mono text-xs font-medium text-aurea-focus"></p>
                    <h2 id="log-detail-title" class="mt-2 font-serif text-2xl text-aurea-ink">Detalle del error</h2>
                </div>
                <button type="button" id="log-detail-close" class="aurea-focus cursor-pointer rounded-md p-2 text-aurea-muted hover:bg-aurea-paper hover:text-aurea-ink" aria-label="Cerrar detalle" title="Cerrar detalle"><?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => 'close','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?></button>
            </div>
            <dl class="mt-6 grid gap-4 text-sm sm:grid-cols-3">
                <div><dt class="text-xs text-aurea-muted">Fecha y hora</dt><dd id="log-detail-date" class="mt-1 text-[#343d37]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Origen</dt><dd id="log-detail-source" class="mt-1 text-[#343d37]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Módulo</dt><dd id="log-detail-module" class="mt-1 text-[#343d37]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Estado</dt><dd id="log-detail-status" class="mt-1 text-[#587262]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Acción</dt><dd id="log-detail-action" class="mt-1 text-[#343d37]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Usuario</dt><dd id="log-detail-user" class="mt-1 text-[#343d37]"></dd></div>
                <div><dt class="text-xs text-aurea-muted">Entidad afectada</dt><dd id="log-detail-entity" class="mt-1 break-words text-[#343d37]"></dd></div>
            </dl>
            <div class="mt-6 space-y-4 border-t border-[#eef0ec] pt-5 text-sm">
                <div><h3 class="text-xs font-medium text-aurea-muted">Ruta</h3><p id="log-detail-route" class="mt-1 break-words font-mono text-xs text-[#343d37]"></p></div>
                <div><h3 class="text-xs font-medium text-aurea-muted">Mensaje mostrado al usuario</h3><p id="log-detail-message" class="mt-1 leading-6 text-[#343d37]"></p></div>
                <div><h3 class="text-xs font-medium text-aurea-muted">Detalle interno</h3><p id="log-detail-detail" class="mt-1 leading-6 text-[#343d37]"></p></div>
                <div id="log-detail-product-context" class="hidden rounded-xl border border-[#e7e2da] bg-[#fbf9f6] p-4"><h3 class="text-xs font-medium text-aurea-muted">Contexto de producto</h3><dl class="mt-3 grid gap-3 text-xs sm:grid-cols-3"><div><dt class="text-[#a39a8e]">Producto</dt><dd id="log-detail-product" class="mt-1 text-[#4f4a45]"></dd></div><div><dt class="text-[#a39a8e]">SKU</dt><dd id="log-detail-sku" class="mt-1 font-mono text-[#4f4a45]"></dd></div><div class="sm:col-span-1"><dt class="text-[#a39a8e]">Selección</dt><dd id="log-detail-selection" class="mt-1 text-[#4f4a45]"></dd></div></dl></div>
                <div class="rounded-xl bg-[#fbf9f6] p-4"><h3 class="text-xs font-medium text-aurea-muted">Información técnica</h3><dl class="mt-3 grid gap-3 text-xs sm:grid-cols-3"><div><dt class="text-[#a39a8e]">Tipo de excepción</dt><dd id="log-detail-exception" class="mt-1 break-words font-mono text-[#4f4a45]"></dd></div><div class="sm:col-span-2"><dt class="text-[#a39a8e]">Archivo</dt><dd id="log-detail-file" class="mt-1 break-words font-mono text-[#4f4a45]"></dd></div><div><dt class="text-[#a39a8e]">Línea</dt><dd id="log-detail-line" class="mt-1 font-mono text-[#4f4a45]"></dd></div></dl></div>
            </div>
            <div class="mt-6 flex justify-end"><button type="button" id="log-detail-close-bottom" class="aurea-focus cursor-pointer rounded-lg border border-aurea-border px-4 py-2.5 text-sm font-medium text-aurea-muted hover:bg-aurea-paper">Cerrar</button></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const logSearch = document.getElementById('log-search');
        const logModuleFilter = document.getElementById('log-module-filter');
        const logSourceFilter = document.getElementById('log-source-filter');
        const logStatusFilter = document.getElementById('log-status-filter');
        const logDateFilter = document.getElementById('log-date-filter');
        const logRows = Array.from(document.querySelectorAll('.log-row'));
        const logNoResults = document.getElementById('log-no-results');
        const logModal = document.getElementById('log-detail-modal');
        const logModalClose = document.getElementById('log-detail-close');
        const logModalCloseBottom = document.getElementById('log-detail-close-bottom');
        let logDetailTrigger = null;

        const updateLogRows = () => {
            const search = logSearch?.value.trim().toLowerCase() ?? '';
            const module = logModuleFilter?.value ?? '';
            const source = logSourceFilter?.value ?? '';
            const status = logStatusFilter?.value ?? '';
            const date = logDateFilter?.value ?? '';
            let visibleRows = 0;

            logRows.forEach((row) => {
                const matches = (!search || row.dataset.search.includes(search)) &&
                    (!source || row.dataset.source === source) &&
                    (!module || row.dataset.module === module) &&
                    (!status || row.dataset.status === status) &&
                    (!date || row.dataset.date >= date);

                row.classList.toggle('hidden', !matches);
                visibleRows += matches ? 1 : 0;
            });

            logNoResults?.classList.toggle('hidden', visibleRows > 0);
        };

        const toggleLogModal = (open) => {
            logModal?.classList.toggle('hidden', !open);
            logModal?.classList.toggle('flex', open);

            if (!open) {
                logDetailTrigger?.focus();
                logDetailTrigger = null;
            }
        };

        document.querySelectorAll('.log-detail-trigger').forEach((trigger) => {
            trigger.addEventListener('click', () => {
                logDetailTrigger = trigger;
                const fields = ['code', 'date', 'source', 'module', 'action', 'user', 'route', 'entity', 'message', 'detail', 'exception', 'file', 'line', 'status'];

                fields.forEach((field) => {
                    document.getElementById(`log-detail-${field}`).textContent = trigger.dataset[field];
                });

                const productContext = document.getElementById('log-detail-product-context');
                const hasProductContext = trigger.dataset.product || trigger.dataset.sku || trigger.dataset.selection;

                productContext.classList.toggle('hidden', !hasProductContext);
                document.getElementById('log-detail-product').textContent = trigger.dataset.product;
                document.getElementById('log-detail-sku').textContent = trigger.dataset.sku;
                document.getElementById('log-detail-selection').textContent = trigger.dataset.selection;

                toggleLogModal(true);
                logModalClose?.focus();
            });
        });

        [logSearch, logModuleFilter, logSourceFilter, logStatusFilter, logDateFilter].forEach((control) => {
            control?.addEventListener('input', updateLogRows);
            control?.addEventListener('change', updateLogRows);
        });
        document.querySelector('[data-filter-section]')?.addEventListener('filters-cleared', updateLogRows);
        [logModalClose, logModalCloseBottom].forEach((control) => control?.addEventListener('click', () => toggleLogModal(false)));
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                toggleLogModal(false);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Registro de errores', 'sectionTitle' => 'Registro de errores'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/error-logs.blade.php ENDPATH**/ ?>