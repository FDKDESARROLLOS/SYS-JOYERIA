
<?php echo $__env->make('layouts.error', [
    'code' => '404',
    'title' => 'Página no encontrada',
    'message' => 'La página que buscas no existe o fue movida.',
    'actions' => [
        ['label' => 'Volver al dashboard', 'url' => url('/dashboard')],
        ['label' => 'Ir al inicio', 'url' => url('/')],
    ],
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/errors/404.blade.php ENDPATH**/ ?>