<?php $__env->startSection('content'); ?>
    <?php
        $orders = config('aurea-demo.orders', []);
        $order = collect($orders)->firstWhere('order_number', request()->route('orderNumber'));
        abort_unless(is_array($order), 404);
        $fulfillment = $order['fulfillment'];
        abort_unless($fulfillment['fulfillment_status'] !== 'No aplica', 404);
        $carriers = ['Estafeta', 'DHL', 'FedEx', 'Otra'];
        $fulfillmentStatusClasses = [
            'Pendiente de preparación' => 'text-[#947142]',
            'Preparando' => 'text-[#61758b]',
            'Despachado' => 'text-[#61758b]',
            'Entregado' => 'text-[#5b8668]',
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Pedidos',
                'url' => route('orders.index'),
            ],
            [
                'label' => $order['order_number'],
                'url' => route('orders.show', ['orderNumber' => $order['order_number']]),
            ],
            [
                'label' => 'Registrar despacho',
                'url' => null,
            ],
        ],'title' => 'Registrar despacho','description' => 'Completa visualmente los datos de envío para el pedido '.e($order['order_number']).'.','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Pedidos',
                'url' => route('orders.index'),
            ],
            [
                'label' => $order['order_number'],
                'url' => route('orders.show', ['orderNumber' => $order['order_number']]),
            ],
            [
                'label' => 'Registrar despacho',
                'url' => null,
            ],
        ]),'title' => 'Registrar despacho','description' => 'Completa visualmente los datos de envío para el pedido '.e($order['order_number']).'.','required' => true]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a
                href="<?php echo e(route('orders.show', ['orderNumber' => $order['order_number']])); ?>"
                class="aurea-focus inline-flex items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] hover:border-aurea-gold hover:text-aurea-focus"
            >Volver al pedido</a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="mb-7 flex flex-wrap items-center gap-3 border-b border-[#eef0ec] pb-5">
        <span class="text-sm text-[#68736c]">Estado actual:</span>
        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $fulfillment['fulfillment_status'],'statusClass' => $fulfillmentStatusClasses[$fulfillment['fulfillment_status']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fulfillment['fulfillment_status']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fulfillmentStatusClasses[$fulfillment['fulfillment_status']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
    </div>

    <form class="space-y-7">
        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Datos del despacho','description' => 'Registra la paquetería y la información necesaria para enviar el pedido.','id' => 'dispatch-data-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Datos del despacho','description' => 'Registra la paquetería y la información necesaria para enviar el pedido.','id' => 'dispatch-data-title']); ?>
            <div class="grid gap-5 sm:grid-cols-2">
                <label>
                    <span class="admin-form-label admin-form-label-required">Paquetería</span>
                    <select name="carrier" class="admin-form-input" required>
                        <option value="">Seleccionar paquetería</option>
                        <?php $__currentLoopData = $carriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($carrier); ?>" <?php if($fulfillment['carrier'] === $carrier): echo 'selected'; endif; ?>><?php echo e($carrier); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>
                    <span class="admin-form-label admin-form-label-required">Número de guía</span>
                    <input
                        type="text"
                        name="tracking_number"
                        value="<?php echo e($fulfillment['tracking_number']); ?>"
                        placeholder="Ej. 1234567890"
                        class="admin-form-input"
                        required
                    />
                </label>
                <label>
                    <span class="admin-form-label admin-form-label-required">Fecha de envío</span>
                    <input
                        type="datetime-local"
                        name="shipped_at"
                        value="<?php echo e($fulfillment['shipped_at']); ?>"
                        class="admin-form-input"
                        required
                    />
                </label>
                <label>
                    <span class="admin-form-label">Entrega estimada</span>
                    <input
                        type="date"
                        name="estimated_delivery"
                        value="<?php echo e($fulfillment['estimated_delivery']); ?>"
                        class="admin-form-input"
                    />
                </label>
                <label class="sm:col-span-2">
                    <span class="admin-form-label">Notas</span>
                    <textarea
                        name="shipping_notes"
                        rows="4"
                        placeholder="Ej. Paquete entregado a la paquetería."
                        class="admin-form-input resize-y"
                    ><?php echo e($fulfillment['shipping_notes']); ?></textarea>
                </label>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>

        <div class="flex justify-end">
            <button
                type="button"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]"
            >Confirmar despacho</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Registrar despacho', 'sectionTitle' => 'Registrar despacho'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/orders/dispatch.blade.php ENDPATH**/ ?>