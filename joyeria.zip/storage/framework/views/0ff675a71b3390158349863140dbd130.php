<?php $__env->startSection('content'); ?>
    <?php
        $initials = collect(preg_split('/\s+/', trim($user->name)))
            ->filter()
            ->take(2)
            ->map(fn($namePart) => mb_strtoupper(mb_substr($namePart, 0, 1)))
            ->implode('');

        $roleLabel = match ($user->role) {
            'admin' => 'Administrador',
            'technical' => 'Equipo técnico',
            default => ucfirst($user->role),
        };
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
        [
            'label' => 'Mi perfil',
            'url' => null,
        ],
    ],'title' => 'Mi perfil','description' => 'Consulta y actualiza la información visible de tu cuenta administrativa.','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        [
            'label' => 'Mi perfil',
            'url' => null,
        ],
    ]),'title' => 'Mi perfil','description' => 'Consulta y actualiza la información visible de tu cuenta administrativa.','required' => true]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <button type="submit" form="profile-form"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]">
                Guardar cambios
            </button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <form id="profile-form" method="POST" action="<?php echo e(route('profile.update')); ?>" class="space-y-7">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Información personal','description' => 'Mantén actualizados los datos con los que administras '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'profile-information-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Información personal','description' => 'Mantén actualizados los datos con los que administras '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.','id' => 'profile-information-title']); ?>
            <div class="flex items-center gap-4 border-b border-[#eef0ec] pb-5">
                <div class="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#eadfce] text-sm font-semibold text-[#806441]"
                    aria-label="Avatar de <?php echo e($user->name); ?>">
                    <?php echo e($initials); ?>

                </div>

                <div>
                    <p class="text-sm font-medium text-aurea-ink">
                        <?php echo e($user->name); ?>

                    </p>

                    <p class="mt-1 text-xs text-aurea-muted">
                        <?php echo e($roleLabel); ?>

                    </p>
                </div>
            </div>

            <?php if(session('status')): ?>
                <div class="mt-5 rounded-lg bg-green-50 px-4 py-3 text-sm text-green-700">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="mt-5 grid gap-5 sm:grid-cols-2">
                <label for="profile-name">
                    <span class="admin-form-label admin-form-label-required">
                        Nombre
                    </span>

                    <input id="profile-name" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>"
                        class="admin-form-input aurea-focus" autocomplete="name" required />

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label for="profile-email">
                    <span class="admin-form-label admin-form-label-required">
                        Correo
                    </span>

                    <input id="profile-email" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                        class="admin-form-input aurea-focus" autocomplete="email" required />

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <div>
                    <span class="admin-form-label">
                        Rol
                    </span>

                    <div
                        class="flex min-h-11 items-center rounded-lg border border-[#dfe2dc] bg-[#fbfbf9] px-3 text-sm text-[#56625a]">
                        <?php echo e($roleLabel); ?>

                    </div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Mi perfil', 'sectionTitle' => 'Mi perfil'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/profile/edit.blade.php ENDPATH**/ ?>