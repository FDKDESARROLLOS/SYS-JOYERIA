<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'description',
    'checked' => false,
    'id' => null,
    'name' => null,
    'disabled' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'description',
    'checked' => false,
    'id' => null,
    'name' => null,
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $toggleId = $id ?? 'toggle-' . \Illuminate\Support\Str::slug($label);
    $descriptionId = $toggleId . '-description';
    $isChecked = filter_var($checked, FILTER_VALIDATE_BOOLEAN);
?>

<label for="<?php echo e($toggleId); ?>" class="flex cursor-pointer items-start justify-between gap-3">
    <span>
        <span class="block text-sm text-[#3d4640] dark:text-[#eeeae2]"><?php echo e($label); ?></span>
        <span id="<?php echo e($descriptionId); ?>" class="mt-0.5 block text-[11px] leading-4 text-[#929b94] dark:text-[#aeb4ae]"><?php echo e($description); ?></span>
    </span>
    <span class="relative mt-0.5 inline-flex shrink-0 items-center">
        <?php if($name): ?>
            <input type="hidden" name="<?php echo e($name); ?>" value="0" <?php if($disabled): echo 'disabled'; endif; ?> />
        <?php endif; ?>
        <input
            id="<?php echo e($toggleId); ?>"
            type="checkbox"
            class="peer sr-only"
            <?php if($name): ?> name="<?php echo e($name); ?>" <?php endif; ?>
            value="1"
            aria-describedby="<?php echo e($descriptionId); ?>"
            <?php if($isChecked): echo 'checked'; endif; ?>
            <?php if($disabled): echo 'disabled'; endif; ?>
        />
        <span class="admin-toggle-track relative h-5 w-9 rounded-full transition peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-aurea-focus peer-focus-visible:outline-offset-2 after:absolute after:left-1 after:top-1 after:h-3 after:w-3 after:rounded-full after:bg-white after:transition-all peer-checked:after:translate-x-4 dark:after:bg-[#f7f4ed]"></span>
    </span>
</label>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/toggle.blade.php ENDPATH**/ ?>