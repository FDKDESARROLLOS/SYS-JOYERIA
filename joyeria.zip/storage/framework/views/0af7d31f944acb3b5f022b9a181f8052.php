<?php $__env->startSection('content'); ?>
    <?php
        $movementTypeStyles = [
            'Entrada' => 'text-[#5b8668]',
            'Salida' => 'text-aurea-danger',
            'Ajuste' => 'text-[#947142]',
            'Devolución' => 'text-[#61758b]',
        ];
        $catalogProducts = collect(config('aurea-demo.catalog_products', []));
        $productImageForSku = fn ($sku) => $catalogProducts->first(
            fn ($product) => $sku === $product['base_sku'] || str_starts_with($sku, $product['base_sku'] . '-')
        )['image'] ?? null;
        $inventoryMovements = collect(config('aurea-demo.inventory_movements', []))->map(function ($movement) use ($movementTypeStyles, $productImageForSku) {
            $quantityClass = $movement['quantity'] >= 0 ? 'text-[#5b8668]' : 'text-aurea-danger';

            return array_merge($movement, [
                'image' => $productImageForSku($movement['sku']),
                'type_class' => $movementTypeStyles[$movement['type']] ?? 'text-[#68736c]',
                'quantity_label' => sprintf('%+d', $movement['quantity']),
                'quantity_class' => $quantityClass,
            ]);
        });
        $movementTypes = ['Entrada', 'Salida', 'Ajuste', 'Devolución'];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            [
                'label' => 'Inventario',
                'url' => route('inventory.stock'),
            ],
            [
                'label' => 'Movimientos',
                'url' => null,
            ],
        ],'title' => 'Movimientos','description' => 'Consulta el historial que explica cada cambio en las existencias del catálogo.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            [
                'label' => 'Inventario',
                'url' => route('inventory.stock'),
            ],
            [
                'label' => 'Movimientos',
                'url' => null,
            ],
        ]),'title' => 'Movimientos','description' => 'Consulta el historial que explica cada cambio en las existencias del catálogo.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a
                href="<?php echo e(route('inventory.movements.create')); ?>"
                class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f]"
            >
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                    <path d="M12 5v14M5 12h14" />
                </svg>
                Nuevo movimiento
            </a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <section
        class="mb-7 rounded-2xl border border-aurea-border bg-aurea-surface p-5 shadow-[0_5px_20px_rgba(35,42,37,0.03)] sm:p-6"
        aria-labelledby="movement-filters-title"
    >
        <div class="mb-5">
            <h3 id="movement-filters-title" class="font-serif text-xl text-[#28302b]">Filtrar movimientos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Consulta una operación por producto, referencia o tipo.</p>
        </div>
        <div class="grid gap-4 sm:grid-cols-3">
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Buscar movimiento</span>
                <input
                    type="search"
                    placeholder="Ej. Anillo Aura, AU-1048-T6 o ENT-0001"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none placeholder:text-[#adb4ae] focus:border-aurea-gold"
                />
            </label>
            <?php if (isset($component)) { $__componentOriginalae2b664bfbf39dde620003b48f024607 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae2b664bfbf39dde620003b48f024607 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-select','data' => ['label' => 'Tipo de movimiento','options' => $movementTypes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Tipo de movimiento','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movementTypes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $attributes = $__attributesOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__attributesOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae2b664bfbf39dde620003b48f024607)): ?>
<?php $component = $__componentOriginalae2b664bfbf39dde620003b48f024607; ?>
<?php unset($__componentOriginalae2b664bfbf39dde620003b48f024607); ?>
<?php endif; ?>
            <label>
                <span class="mb-2 block text-xs font-medium text-[#68736c]">Fecha</span>
                <input
                    type="date"
                    class="aurea-focus w-full rounded-lg border border-[#dfe2dc] bg-aurea-surface px-3 py-2.5 text-sm text-[#56625a] outline-none focus:border-aurea-gold"
                />
            </label>
        </div>
    </section>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="movements-list-title"
    >
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="movements-list-title" class="font-serif text-xl text-[#28302b]">Historial de movimientos</h3>
            <p class="mt-1 text-xs text-[#8a938d]">Mostrando <?php echo e($inventoryMovements->count()); ?> movimientos ficticios.</p>
        </div>

        <?php if($inventoryMovements->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay movimientos todavía','description' => 'Las entradas, salidas y ajustes de inventario aparecerán aquí.','actionUrl' => route('inventory.movements.create'),'actionLabel' => 'Registrar movimiento']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay movimientos todavía','description' => 'Las entradas, salidas y ajustes de inventario aparecerán aquí.','action-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('inventory.movements.create')),'action-label' => 'Registrar movimiento']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
        <div class="hidden overflow-x-auto sm:block">
            <table class="admin-table w-full min-w-300 text-left text-sm">
                <caption class="sr-only">Historial de movimientos de inventario</caption>
                <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                    <tr>
                        <th scope="col" class="px-5 py-3 font-medium sm:px-6">Fecha</th>
                        <th scope="col" class="px-3 py-3 font-medium">Producto</th>
                        <th scope="col" class="px-3 py-3 font-medium">Variante</th>
                        <th scope="col" class="px-3 py-3 font-medium">SKU</th>
                        <th scope="col" class="px-3 py-3 font-medium">Tipo</th>
                        <th scope="col" class="px-3 py-3 font-medium">Cantidad</th>
                        <th scope="col" class="px-3 py-3 font-medium">Stock anterior</th>
                        <th scope="col" class="px-3 py-3 font-medium">Stock resultante</th>
                        <th scope="col" class="px-3 py-3 font-medium">Motivo / Referencia</th>
                        <th scope="col" class="px-5 py-3 font-medium sm:px-6">Usuario</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#f0f1ed]">
                    <?php $__currentLoopData = $inventoryMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                            <td class="whitespace-nowrap px-5 py-4 text-xs text-[#68736c] sm:px-6"><?php echo e($movement['date']); ?></td>
                            <td class="px-3 py-4">
                                <div class="flex items-center gap-3">
                                    <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $movement['image'],'alt' => $movement['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['image']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                                    <span class="font-medium text-[#343d37]"><?php echo e($movement['product']); ?></span>
                                </div>
                            </td>
                            <td class="px-3 py-4"><?php echo e($movement['variant']); ?></td>
                            <td class="px-3 py-4 text-xs text-[#929b94]"><?php echo e($movement['sku']); ?></td>
                            <td class="px-3 py-4">
                                <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $movement['type'],'statusClass' => $movement['type_class']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['type']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['type_class'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                            </td>
                            <td class="px-3 py-4 text-base font-semibold <?php echo e($movement['quantity_class']); ?>">
                                <?php echo e($movement['quantity_label']); ?>

                            </td>
                            <td class="px-3 py-4 text-[#68736c]"><?php echo e($movement['previous_stock']); ?></td>
                            <td class="px-3 py-4 font-medium text-[#343d37]"><?php echo e($movement['resulting_stock']); ?></td>
                            <td class="px-3 py-4">
                                <p class="text-[#5b655e]"><?php echo e($movement['reason']); ?></p>
                                <p class="mt-1 text-xs text-[#929b94]"><?php echo e($movement['reference']); ?></p>
                            </td>
                            <td class="px-5 py-4 text-xs text-[#68736c] sm:px-6"><?php echo e($movement['user']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="divide-y divide-[#f0f1ed] sm:hidden">
            <?php $__currentLoopData = $inventoryMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="px-5 py-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex min-w-0 items-center gap-3">
                            <?php if (isset($component)) { $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-thumbnail','data' => ['image' => $movement['image'],'alt' => $movement['product'],'size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['image']),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['product']),'size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $attributes = $__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__attributesOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65)): ?>
<?php $component = $__componentOriginal9e01c79f95cd8be0e492bb15a596fb65; ?>
<?php unset($__componentOriginal9e01c79f95cd8be0e492bb15a596fb65); ?>
<?php endif; ?>
                            <div class="min-w-0">
                            <p class="text-xs text-[#929b94]"><?php echo e($movement['date']); ?></p>
                            <p class="mt-1 text-sm font-medium text-[#343d37]"><?php echo e($movement['product']); ?></p>
                            <p class="mt-1 text-xs text-[#929b94]"><?php echo e($movement['variant']); ?></p>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $movement['type'],'statusClass' => $movement['type_class']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['type']),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement['type_class'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                    </div>
                    <dl class="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                        <div>
                            <dt class="text-[#929b94]">SKU</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($movement['sku']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Cantidad</dt>
                            <dd class="mt-0.5 text-base font-semibold <?php echo e($movement['quantity_class']); ?>"><?php echo e($movement['quantity_label']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Stock resultante</dt>
                            <dd class="mt-0.5 font-medium text-[#343d37]"><?php echo e($movement['resulting_stock']); ?></dd>
                        </div>
                        <div>
                            <dt class="text-[#929b94]">Referencia</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($movement['reference']); ?></dd>
                        </div>
                        <div class="col-span-2">
                            <dt class="text-[#929b94]">Motivo</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($movement['reason']); ?></dd>
                        </div>
                        <div class="col-span-2">
                            <dt class="text-[#929b94]">Usuario</dt>
                            <dd class="mt-0.5 text-[#5b655e]"><?php echo e($movement['user']); ?></dd>
                        </div>
                    </dl>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Movimientos', 'sectionTitle' => 'Movimientos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/inventory/movements.blade.php ENDPATH**/ ?>