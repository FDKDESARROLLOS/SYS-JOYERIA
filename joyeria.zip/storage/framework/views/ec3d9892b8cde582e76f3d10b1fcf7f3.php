<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'message',
    'type' => 'success',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'message',
    'type' => 'success',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $styles = [
        'success' => 'border-[#d8e7dc] bg-[#f4faf5] text-[#4f765a]',
        'error' => 'border-[#efd8d3] bg-[#fdf6f4] text-[#94594e]',
        'info' => 'border-[#dce5eb] bg-[#f5f9fb] text-[#557184]',
    ];
    $icons = [
        'success' => 'M5 12.5 10 17 19 7',
        'error' => 'M7 7l10 10M17 7 7 17',
        'info' => 'M12 7v.01M12 11v6',
    ];
?>

<div class="flex items-start gap-3 rounded-xl border px-4 py-3 text-sm <?php echo e($styles[$type] ?? $styles['info']); ?>" role="status">
    <svg class="mt-0.5 h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="<?php echo e($icons[$type] ?? $icons['info']); ?>" />
    </svg>
    <span><?php echo e($message); ?></span>
</div>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/components/admin/feedback-message.blade.php ENDPATH**/ ?>