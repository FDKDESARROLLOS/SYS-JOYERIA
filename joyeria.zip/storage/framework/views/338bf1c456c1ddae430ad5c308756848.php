<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
            ['label' => 'Productos', 'url' => route('products.index')],
            ['label' => $product['name'], 'url' => route('products.edit', $productModel)],
            ['label' => 'Variantes', 'url' => route('products.variants.index', $productModel)],
            ['label' => 'Nueva variante', 'url' => null],
        ],'title' => 'Nueva variante','description' => 'Añade una versión de '.e($product['name']).' al catálogo.','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Productos', 'url' => route('products.index')],
            ['label' => $product['name'], 'url' => route('products.edit', $productModel)],
            ['label' => 'Variantes', 'url' => route('products.variants.index', $productModel)],
            ['label' => 'Nueva variante', 'url' => null],
        ]),'title' => 'Nueva variante','description' => 'Añade una versión de '.e($product['name']).' al catálogo.','required' => true]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a href="<?php echo e(route('products.variants.index', $productModel)); ?>"
                class="aurea-focus inline-flex items-center justify-center rounded-lg border border-[#dfe2dc] px-4 py-2.5 text-sm font-medium text-[#68736c] hover:border-aurea-gold hover:text-aurea-focus">Cancelar</a>
            <button type="submit" form="variant-form"
                class="aurea-focus inline-flex items-center justify-center rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-[#9f793f]">Guardar variante</button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.product-context','data' => ['product' => $product,'editUrl' => route('products.edit', $productModel)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.product-context'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('products.edit', $productModel))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793)): ?>
<?php $attributes = $__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793; ?>
<?php unset($__attributesOriginal5c45b9b25df1c7e8f56fe5a0d52f9793); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793)): ?>
<?php $component = $__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793; ?>
<?php unset($__componentOriginal5c45b9b25df1c7e8f56fe5a0d52f9793); ?>
<?php endif; ?>

    <?php echo $__env->make('products.variants._form', [
        'product' => $product,
        'productModel' => $productModel,
        'variant' => $variant,
        'isEditing' => false,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Nueva variante', 'sectionTitle' => 'Nueva variante'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/products/variants/create.blade.php ENDPATH**/ ?>