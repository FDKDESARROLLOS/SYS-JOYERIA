
<?php echo $__env->make('layouts.error', [
    'code' => '500',
    'title' => 'Ocurrió un problema interno',
    'message' => 'No fue posible completar la solicitud. Inténtalo nuevamente más tarde.',
    'actions' => [
        ['label' => 'Volver al dashboard', 'url' => url('/dashboard')],
        ['label' => 'Intentar nuevamente', 'url' => url()->current()],
    ],
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/errors/500.blade.php ENDPATH**/ ?>