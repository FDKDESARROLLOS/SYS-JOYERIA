
<?php echo $__env->make('layouts.error', [
    'code' => '419',
    'title' => 'Sesión expirada',
    'message' => 'Tu sesión ha expirado. Inicia sesión nuevamente para continuar.',
    'actions' => [
        ['label' => 'Volver al inicio de sesión', 'url' => url('/login')],
    ],
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/errors/419.blade.php ENDPATH**/ ?>