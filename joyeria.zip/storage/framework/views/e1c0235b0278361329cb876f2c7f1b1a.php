<?php
    $collectionStatuses = [
        1 => 'Activa',
        0 => 'Inactiva',
    ];
?>

<form id="collection-form" method="POST"
    action="<?php echo e($isEditing ? route('collections.update', $collection) : route('collections.store')); ?>" class="space-y-7">
    <?php echo csrf_field(); ?>

    <?php if($isEditing): ?>
        <?php echo method_field('PATCH'); ?>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-[#ecd0cb] bg-[#fff8f6] px-4 py-3 text-sm text-aurea-danger" role="alert">
            Revisa los campos marcados para continuar.
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-section','data' => ['number' => '01','title' => 'Información general','description' => 'Define el nombre y la presencia de la colección dentro del catálogo.','id' => 'collection-general-title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => '01','title' => 'Información general','description' => 'Define el nombre y la presencia de la colección dentro del catálogo.','id' => 'collection-general-title']); ?>
        <div class="grid gap-5 sm:grid-cols-2">
            <label class="sm:col-span-2">
                <span class="admin-form-label admin-form-label-required">Nombre</span>
                <input id="collection-name" type="text" name="name" value="<?php echo e(old('name', $collection->name)); ?>"
                    placeholder="Ej. Eternal"
                    class="admin-form-input" required />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                <span class="admin-form-label">Slug</span>
                <input id="collection-slug-preview" type="text"
                    value="<?php echo e($collection->slug); ?>" class="admin-form-input bg-[#f8f9f6] text-[#929b94]"
                    readonly aria-live="polite" />
                <span class="mt-1 block text-xs text-[#929b94]">Se genera automáticamente a partir del nombre.</span>
            </label>

            <label>
                <span class="admin-form-label admin-form-label-required">Estado</span>
                <select name="status" class="admin-form-input" required>
                    <?php $__currentLoopData = $collectionStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"
                            <?php if((string) old('status', $collection->status ?? true) === (string) $value): echo 'selected'; endif; ?>>
                            <?php echo e($label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $attributes = $__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__attributesOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3)): ?>
<?php $component = $__componentOriginalba421f08b6b43aecb09f8eebe577a4f3; ?>
<?php unset($__componentOriginalba421f08b6b43aecb09f8eebe577a4f3); ?>
<?php endif; ?>
</form>

<?php if (! $__env->hasRenderedOnce('2072375a-d8bd-4a08-92cc-3f65efe92426')): $__env->markAsRenderedOnce('2072375a-d8bd-4a08-92cc-3f65efe92426');
$__env->startPush('scripts'); ?>
    <script>
        const collectionNameInput = document.getElementById('collection-name');
        const collectionSlugPreview = document.getElementById('collection-slug-preview');

        if (collectionNameInput && collectionSlugPreview) {
            const slugify = (value) => value
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');

            collectionNameInput.addEventListener('input', () => {
                collectionSlugPreview.value = slugify(collectionNameInput.value);
            });

            if (!collectionSlugPreview.value && collectionNameInput.value) {
                collectionSlugPreview.value = slugify(collectionNameInput.value);
            }
        }
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/collections/_form.blade.php ENDPATH**/ ?>