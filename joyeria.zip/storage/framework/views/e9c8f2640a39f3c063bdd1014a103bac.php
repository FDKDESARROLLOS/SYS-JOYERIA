<?php $__env->startSection('content'); ?>
    <div>
        <p class="text-[10px] font-semibold uppercase tracking-[.22em] text-aurea-focus">Recuperación de acceso</p>
        <h2 id="auth-title" class="mt-3 font-brand text-4xl text-[#222222]">Recuperar contraseña</h2>
        <p class="mt-3 text-sm leading-6 text-aurea-muted">Ingresa tu correo electrónico y te enviaremos las instrucciones
            para restablecer tu contraseña.</p>
    </div>

    <form class="mt-8 space-y-5" aria-label="Recuperar contraseña" method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>

        <label class="block">
            <span class="admin-form-label">Correo electrónico</span>

            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                placeholder="nombre@tienda.com" class="admin-form-input aurea-focus" />

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <?php if(session('status')): ?>
            <p class="rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
                <?php echo e(session('status')); ?>

            </p>
        <?php endif; ?>

        <button type="submit"
            class="aurea-focus inline-flex w-full cursor-pointer items-center justify-center rounded-lg bg-aurea-gold px-4 py-3 text-sm font-medium text-white shadow-sm hover:bg-[#966f3f]">
            Enviar instrucciones
        </button>

        <a href="<?php echo e(route('login')); ?>"
            class="aurea-focus flex w-full items-center justify-center rounded-lg border border-aurea-border px-4 py-3 text-sm font-medium text-aurea-muted hover:bg-aurea-paper hover:text-aurea-focus">
            Volver a iniciar sesión
        </a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Recuperar contraseña'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>