<?php $__env->startSection('content'); ?>
    <?php
        $statusClasses = [
            1 => 'text-[#5b8668]',
            0 => 'text-[#929b94]',
        ];

        $roleLabels = [
            'admin' => 'Administrador',
            'technical' => 'Equipo técnico',
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['breadcrumbs' => [
        [
            'label' => 'Configuración',
            'url' => null,
        ],
        [
            'label' => 'Usuarios administrativos',
            'url' => null,
        ],
    ],'title' => 'Usuarios administrativos','description' => 'Consulta y organiza las personas que administran la tienda '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        [
            'label' => 'Configuración',
            'url' => null,
        ],
        [
            'label' => 'Usuarios administrativos',
            'url' => null,
        ],
    ]),'title' => 'Usuarios administrativos','description' => 'Consulta y organiza las personas que administran la tienda '.e(config('aurea-demo.store_settings.store_name', 'Tienda')).'.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a href="<?php echo e(route('settings.admin-users.create')); ?>"
                class="aurea-focus inline-flex w-fit items-center gap-2 rounded-lg bg-aurea-gold px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#9f793f]">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"
                    aria-hidden="true">
                    <path d="M12 5v14M5 12h14" />
                </svg>

                Nuevo usuario
            </a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.flash-messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.flash-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $attributes = $__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__attributesOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a)): ?>
<?php $component = $__componentOriginaldb1b157d84f8f63332f3508c9e385c0a; ?>
<?php unset($__componentOriginaldb1b157d84f8f63332f3508c9e385c0a); ?>
<?php endif; ?>

    <section
        class="overflow-hidden rounded-2xl border border-aurea-border bg-aurea-surface shadow-[0_5px_20px_rgba(35,42,37,0.03)]"
        aria-labelledby="admin-users-list-title">
        <div class="border-b border-[#eef0ec] px-5 py-5 sm:px-6">
            <h3 id="admin-users-list-title" class="font-serif text-xl text-[#28302b]">
                Listado de usuarios
            </h3>

            <p class="mt-1 text-xs text-[#8a938d]">
                Mostrando <?php echo e($users->count()); ?> de <?php echo e($users->total()); ?> usuarios administrativos.
            </p>
        </div>

        <?php if($users->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No hay usuarios administrativos todavía','description' => 'Agrega un usuario para compartir la administración del panel.','actionUrl' => route('settings.admin-users.create'),'actionLabel' => 'Agregar usuario']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No hay usuarios administrativos todavía','description' => 'Agrega un usuario para compartir la administración del panel.','action-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('settings.admin-users.create')),'action-label' => 'Agregar usuario']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="hidden overflow-x-auto sm:block">
                <table class="admin-table w-full min-w-200 text-left text-sm">
                    <caption class="sr-only">
                        Listado de usuarios administrativos
                    </caption>

                    <thead class="bg-[#fbfbf9] text-[10px] uppercase tracking-wider text-[#9ca49e]">
                        <tr>
                            <th scope="col" class="px-5 py-3 font-medium sm:px-6">Usuario</th>
                            <th scope="col" class="px-3 py-3 font-medium">Correo</th>
                            <th scope="col" class="px-3 py-3 font-medium">Rol</th>
                            <th scope="col" class="px-3 py-3 font-medium">Estado</th>
                            <th scope="col" class="px-3 py-3 font-medium">Último acceso</th>
                            <th scope="col" class="px-5 py-3 text-right font-medium sm:px-6">Acciones</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-[#f0f1ed]">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $initials = collect(preg_split('/\s+/', trim($user->name)))
                                    ->filter()
                                    ->take(2)
                                    ->map(fn($namePart) => mb_strtoupper(mb_substr($namePart, 0, 1)))
                                    ->implode('');

                                $statusLabel = $user->status ? 'Activo' : 'Inactivo';
                            ?>

                            <tr class="text-[#5b655e] hover:bg-[#fbfbf9]">
                                <td class="px-5 py-4 sm:px-6">
                                    <div class="flex items-center gap-3">
                                        <span
                                            class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#e8ddcf] text-xs font-semibold text-[#8f6d43]">
                                            <?php echo e($initials); ?>

                                        </span>

                                        <span class="font-medium text-[#343d37]">
                                            <?php echo e($user->name); ?>

                                        </span>
                                    </div>
                                </td>

                                <td class="px-3 py-4">
                                    <?php echo e($user->email); ?>

                                </td>

                                <td class="px-3 py-4">
                                    <?php echo e($roleLabels[$user->role] ?? ucfirst($user->role)); ?>

                                </td>

                                <td class="px-3 py-4">
                                    <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $statusLabel,'statusClass' => $statusClasses[$user->status ? 1 : 0]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusLabel),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusClasses[$user->status ? 1 : 0])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                                </td>

                                <td class="whitespace-nowrap px-3 py-4 text-xs text-[#68736c]">
                                    <?php echo e($user->last_login_at?->format('d/m/Y H:i') ?? 'Sin acceso registrado'); ?>

                                </td>
                                <td class="px-5 py-4 text-right sm:px-6">
                                    <x-admin.row-actions :label="$user->name" <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $user->name,'editUrl' => route('settings.admin-users.edit', $user),'deleteUrl' => route('settings.admin-users.destroy', $user),'deleteLabel' => 'usuario administrativo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('settings.admin-users.edit', $user)),'delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('settings.admin-users.destroy', $user)),'delete-label' => 'usuario administrativo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="divide-y divide-[#f0f1ed] sm:hidden">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $initials = collect(preg_split('/\s+/', trim($user->name)))
                            ->filter()
                            ->take(2)
                            ->map(fn($namePart) => mb_strtoupper(mb_substr($namePart, 0, 1)))
                            ->implode('');

                        $statusLabel = $user->status ? 'Activo' : 'Inactivo';
                    ?>

                    <article class="px-5 py-4">
                        <div class="flex items-start justify-between gap-3">
                            <div class="flex min-w-0 items-center gap-3">
                                <span
                                    class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#e8ddcf] text-xs font-semibold text-[#8f6d43]">
                                    <?php echo e($initials); ?>

                                </span>

                                <div class="min-w-0">
                                    <p class="truncate text-sm font-medium text-[#343d37]">
                                        <?php echo e($user->name); ?>

                                    </p>

                                    <p class="mt-1 truncate text-xs text-[#929b94]">
                                        <?php echo e($user->email); ?>

                                    </p>
                                </div>
                            </div>

                            <?php if (isset($component)) { $__componentOriginal72ffe10338c4ec71bdf1582010227fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-badge','data' => ['label' => $statusLabel,'statusClass' => $statusClasses[$user->status ? 1 : 0]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusLabel),'status-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusClasses[$user->status ? 1 : 0])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $attributes = $__attributesOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__attributesOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9)): ?>
<?php $component = $__componentOriginal72ffe10338c4ec71bdf1582010227fb9; ?>
<?php unset($__componentOriginal72ffe10338c4ec71bdf1582010227fb9); ?>
<?php endif; ?>
                        </div>

                        <dl class="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                            <div>
                                <dt class="text-[#929b94]">Rol</dt>

                                <dd class="mt-0.5 text-[#5b655e]">
                                    <?php echo e($roleLabels[$user->role] ?? ucfirst($user->role)); ?>

                                </dd>
                            </div>

                            <div>
                                <dt class="text-[#929b94]">Último acceso</dt>

                                <dd class="mt-0.5 text-[#5b655e]">
                                    <?php echo e($user->last_login_at?->format('d/m/Y H:i') ?? 'Sin acceso registrado'); ?>

                                </dd>
                            </div>
                        </dl>

                        <div class="mt-3 flex justify-end">
                            <?php if (isset($component)) { $__componentOriginal00db464ea9c4f47427f60a0ac000b32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.row-actions','data' => ['label' => $user->name,'editUrl' => route('settings.admin-users.edit', $user),'deleteUrl' => route('settings.admin-users.destroy', $user),'deleteLabel' => 'usuario administrativo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->name),'edit-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('settings.admin-users.edit', $user)),'delete-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('settings.admin-users.destroy', $user)),'delete-label' => 'usuario administrativo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $attributes = $__attributesOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__attributesOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e)): ?>
<?php $component = $__componentOriginal00db464ea9c4f47427f60a0ac000b32e; ?>
<?php unset($__componentOriginal00db464ea9c4f47427f60a0ac000b32e); ?>
<?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="border-t border-[#eef0ec] px-5 py-4 sm:px-6">
                <?php echo e($users->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['title' => 'Usuarios administrativos', 'sectionTitle' => 'Usuarios administrativos'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/FDK/Documents/YUL/JOYERIA/joyeria/resources/views/settings/admin-users/index.blade.php ENDPATH**/ ?>